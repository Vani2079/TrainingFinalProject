package com.hcl.spring.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="PETS")
public class Pet {
	@Id
	@Column(name = "id")
	int id;
	
	@Column(name = "PET_NAME")
	String pet_name;
	
	@Column(name = "PET_AGE")
	int pet_age;
	
	@Column(name = "PET_PLACE")
	String pet_place;
	
	@Column(name = "PET_OWNER_ID")
	String pet_owner_id;
	
	public String getPet_owner_id() {
		return pet_owner_id;
	}
	public void setPet_ownerid(String pet_owner_id) {
		this.pet_owner_id = pet_owner_id;
	}
	public String getPet_place() {
		return pet_place;
	}
	public void setPet_place(String pet_place) {
		this.pet_place = pet_place;
	}
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getPet_name() {
		return pet_name;
	}
	public void setPet_name(String pet_name) {
		this.pet_name = pet_name;
	}
	public int getPet_age() {
		return pet_age;
	}
	public void setPet_age(int pet_age) {
		this.pet_age = pet_age;
	}

}