package com.hcl.spring.model;

import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Size;

public class User {
		
		@NotBlank(message="Name cannot be empty")
		private String Uname;
		@NotBlank(message="password cannot be empty")
		private String password;
		@NotBlank(message="password cannot be empty")
		private String confirmpass; 
		
		public String getUname() {
			return Uname;
		}
		public void setUname(String uname) {
			Uname = uname;
		}
		public String getPassword() {
			return password;
		}
		public void setPassword(String password) {
			this.password = password;
		}
		public String getConfirmpass() {
			return confirmpass;
		}
		public void setConfirmpass(String confirmpass) {
			this.confirmpass = confirmpass;
		}
		
		
		

	}



