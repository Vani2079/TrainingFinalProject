package com.hcl.spring.controls;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.hcl.spring.model.User;


@Controller
public class userregn {
	@RequestMapping("/user")
	public String display(Model model)
	 {
		User u=new User();
		model.addAttribute("UserDetails",u);
	 return "Registration";
	 }
	

	}


