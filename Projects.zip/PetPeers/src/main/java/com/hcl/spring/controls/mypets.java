package com.hcl.spring.controls;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
@Controller
public class mypets {
	
	@RequestMapping("/mypets")
			public String display()
			 {
				
			 return "mypets";
			 }
			

	}



