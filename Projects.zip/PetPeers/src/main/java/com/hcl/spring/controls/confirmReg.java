package com.hcl.spring.controls;

import javax.validation.Valid;

import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.hcl.spring.model.User;


@Controller
public class confirmReg {
	
	@RequestMapping(value = "/confirmReg", method = RequestMethod.POST)
	public String submitForm(@Valid @ModelAttribute("UserDetails") User u,BindingResult br) {
		
		if(br.hasErrors())
		{
			return "Registration";
		}else {
		System.out.println("FirstName:" + u.getUname());
		System.out.println("password :" + u.getPassword());
		System.out.println("ConfirmPassword :" + u.getConfirmpass());
		return "confirmReg";
	}
}

}
