package com.hcl.DAO;

import java.util.List;

import com.hcl.spring.model.Pet;

public interface AnimalDAO {
	public List<Pet> getPets();
	   public int savePet(Pet p);
	   public Boolean savePetByPreparedStatement(final Pet p);

}
