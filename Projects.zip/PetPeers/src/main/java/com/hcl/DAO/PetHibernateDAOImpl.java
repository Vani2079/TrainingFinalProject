package com.hcl.DAO;

import java.util.Iterator;
import java.util.List;

import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;

import com.hcl.DAO.AnimalDAO;
import com.hcl.spring.model.Pet;

public class PetHibernateDAOImpl implements AnimalDAO{
		@Autowired
		private SessionFactory sessionFactory;

		@Override
		public List<Pet> getPets() {
		      Session session = sessionFactory.openSession();
		      Transaction tx = null;
		      List<Pet> pets = null;
		      
		      try {
		         tx = session.beginTransaction();
		        pets = session.createQuery("FROM Pet").list(); 
		        
		         for (Iterator<Pet> iterator = pets.iterator(); iterator.hasNext();){
		            Pet pet = (Pet) iterator.next(); 
		            System.out.print("Pet Name: " + pet.getPet_name()); 
		            System.out.print(" Pet Age: " + pet.getPet_age()); 
		            System.out.println("Pet Place : " +pet.getPet_place()); 
		         }
		         tx.commit();
		      } catch (HibernateException e) {
		         if (tx!=null) tx.rollback();
		         e.printStackTrace(); 
		      } finally {
		         session.close(); 
		      }
			return pets;
		}

		@Override
		public int savePet(Pet p) {
			// TODO Auto-generated method stub
			return 0;
		}

		@Override
		public Boolean savePetByPreparedStatement(Pet p) {
			// TODO Auto-generated method stub
			return null;
		}


}
