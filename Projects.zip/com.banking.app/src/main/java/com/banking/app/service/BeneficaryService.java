package com.banking.app.service;

import com.banking.app.dto.BeneficiaryRequestDto;


public interface BeneficaryService {

	public void saveBeneficary(BeneficiaryRequestDto beneficiaryRequestDto);

	public void BeneficiaryAccountNumber(String toAccountNumber,String fromAccountNumber);
}
