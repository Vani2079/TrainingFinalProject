package com.banking.app.service;

import com.banking.app.dto.TransactionRequestDto;

public interface TransactionService {
	public void saveTransaction(TransactionRequestDto transactionRequestDto);

}
