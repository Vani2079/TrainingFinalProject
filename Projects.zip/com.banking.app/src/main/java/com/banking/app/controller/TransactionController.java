package com.banking.app.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import com.banking.app.dto.TransactionRequestDto;



import com.banking.app.service.AccountService;
import com.banking.app.service.BeneficaryService;
import com.banking.app.service.TransactionService;

@RestController
public class TransactionController {
	@Autowired
	BeneficaryService beneficaryService;
	@Autowired
	AccountService accountService;
	@Autowired
	TransactionService transactionService;

	@PostMapping("/transactions")
	public ResponseEntity<Object> doTransaction(@RequestBody TransactionRequestDto transactionRequestDto) {
		
		accountService.validateAccountNumber(transactionRequestDto);

		
	beneficaryService.BeneficiaryAccountNumber(transactionRequestDto.getToAccountNumber(),
				transactionRequestDto.getFromAccountNumber());
		
		boolean status = accountService.updateBalance(transactionRequestDto.getAmount(),
				transactionRequestDto.getFromAccountNumber(),transactionRequestDto.getToAccountNumber());
		if (status) {
			transactionService.saveTransaction(transactionRequestDto);
			return new ResponseEntity<Object>("Successfully Transaction done!", HttpStatus.OK);
		} else
			return new ResponseEntity<Object>("Unsuccessful! Balance is not Sufficient", HttpStatus.OK);
	}
}
