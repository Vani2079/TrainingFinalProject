package com.banking.app.dto;

import org.springframework.stereotype.Component;

@Component
public class BalanceRequestDto {
	String accountNumber;
	float balance;
	public String getAccountNumber() {
		return accountNumber;
	}
	public void setAccountNumber(String accountNumber) {
		this.accountNumber = accountNumber;
	}
	public float getBalance() {
		return balance;
	}
	public void setBalance(float balance) {
		this.balance = balance;
	}

}
