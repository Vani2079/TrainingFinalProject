package com.banking.app.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.banking.app.model.Loan;
import com.banking.app.service.LoanService;

@RestController
public class LoanController {
	@Autowired
	LoanService loanService;
	
	@GetMapping("/loan")
	public  List<Loan> getLoanId(@RequestParam("amount") double amount)
	{
		List<Loan> result=loanService.getLoanId(amount);
		//foreach(Integer res:result)
		
		return result;
		
	}

}
