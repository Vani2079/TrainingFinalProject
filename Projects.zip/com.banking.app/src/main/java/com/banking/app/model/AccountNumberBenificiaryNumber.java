package com.banking.app.model;

import java.io.Serializable;

import org.springframework.stereotype.Component;

@Component
public class AccountNumberBenificiaryNumber implements Serializable {

	private static final long serialVersionUID = 1L;
	public String getBenificiaryAccountNumber() {
		return benificiaryAccountNumber;
	}
	public void setBenificiaryAccountNumber(String benificiaryAccountNumber) {
		this.benificiaryAccountNumber = benificiaryAccountNumber;
	}
	private String accountNumber;
	 private String benificiaryAccountNumber;
	public String getAccountNumber() {
		return accountNumber;
	}
	public void setAccountNumber(String accountNumber) {
		this.accountNumber = accountNumber;
	}
}
