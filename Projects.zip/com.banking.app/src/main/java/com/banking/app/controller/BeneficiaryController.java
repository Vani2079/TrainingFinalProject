package com.banking.app.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import com.banking.app.dto.BeneficiaryRequestDto;

import com.banking.app.service.AccountService;
import com.banking.app.service.BeneficaryService;

@RestController
public class BeneficiaryController {
	@Autowired
	BeneficaryService beneficaryService;
	@Autowired
	AccountService accountService;

	@PostMapping("/beneficiary")
	public void saveBeneficiary(@RequestBody BeneficiaryRequestDto beneficiaryRequestDto) {

		accountService.validateBeneficiaryAccountNumber(beneficiaryRequestDto);
		
		beneficaryService.saveBeneficary(beneficiaryRequestDto);
	}

}
