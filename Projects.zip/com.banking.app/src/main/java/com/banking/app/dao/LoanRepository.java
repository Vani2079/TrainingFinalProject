package com.banking.app.dao;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.banking.app.model.Loan;


@Repository
public interface LoanRepository extends CrudRepository<Loan, Long> {

}
