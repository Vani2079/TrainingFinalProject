package com.banking.app.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.banking.app.dao.TransactionRepository;
import com.banking.app.dto.TransactionRequestDto;
import com.banking.app.model.Transaction;

@Service
public class TransactionServiceImpl implements TransactionService {
	@Autowired
	TransactionRepository transactionRepository;
	@Autowired
	AccountServiceImpl accountServiceImpl;

	/*To save the transaction details in the table*/
	@Override
	public void saveTransaction(TransactionRequestDto transactionRequestDto) {

		Transaction transaction1 = new Transaction();
		Transaction transaction2 = new Transaction();
		

		transaction1.setAccountNumber(transactionRequestDto.getFromAccountNumber());
		transaction1.setAmount(transactionRequestDto.getAmount());
		transaction1.setDescription("Debited from " + transactionRequestDto.getFromAccountNumber());
		transaction1.setTransactionType("DEBIT");
		transactionRepository.save(transaction1);

		transaction2.setAccountNumber(transactionRequestDto.getToAccountNumber());
		transaction2.setAmount(transactionRequestDto.getAmount());
		transaction2.setDescription("Credited to " + transactionRequestDto.getToAccountNumber());
		transaction2.setTransactionType("CREDIT");
		transactionRepository.save(transaction2);

	}
}
