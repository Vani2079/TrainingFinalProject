package com.banking.app.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.banking.app.dao.LoanRepository;
import com.banking.app.helper.LoanHelper;
import com.banking.app.model.Loan;



@Service
public class LoanServiceImpl implements LoanService{

	@Autowired
	LoanHelper loanHelper;
	@Autowired
	LoanRepository loanRepository;
	@Override
	public List<Loan> getLoanId(double amount) {
	List<Loan> loanDetails=(List<Loan>) loanRepository.findAll();
		
		double calculatedAmount=(amount*60)/100;
		List<Loan> result=loanHelper.getAmount(calculatedAmount,loanDetails);
				return result;
	}

}
