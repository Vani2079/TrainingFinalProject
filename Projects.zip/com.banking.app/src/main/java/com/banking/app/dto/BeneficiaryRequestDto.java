package com.banking.app.dto;

import org.springframework.stereotype.Component;



@Component
public class BeneficiaryRequestDto {
	//AccountNumberBenificiaryNumber accountNumberBenificiaryNumber;
	private String name;
	private String accountNumber;
	private String beneficiaryNumber;
	public String getAccountNumber() {
		return accountNumber;
	}
	public void setAccountNumber(String accountNumber) {
		this.accountNumber = accountNumber;
	}
	public String getBeneficiaryNumber() {
		return beneficiaryNumber;
	}
	public void setBeneficiaryNumber(String beneficiaryNumber) {
		this.beneficiaryNumber = beneficiaryNumber;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}

}
