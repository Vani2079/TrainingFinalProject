package com.banking.app.service;

import java.util.List;

import com.banking.app.model.Loan;



public interface LoanService {
	public List<Loan>  getLoanId(double amount);

}
