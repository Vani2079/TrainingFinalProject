package com.banking.app.model;

import javax.persistence.EmbeddedId;
import javax.persistence.Entity;

@Entity
public class Beneficiary {
@EmbeddedId
AccountNumberBenificiaryNumber accountNumberBenificiaryNumber;
private String name;
public AccountNumberBenificiaryNumber getAccountNumberBenificiaryNumber() {
	return accountNumberBenificiaryNumber;
}
public void setAccountNumberBenificiaryNumber(AccountNumberBenificiaryNumber accountNumberBenificiaryNumber) {
	this.accountNumberBenificiaryNumber = accountNumberBenificiaryNumber;
}
public String getName() {
	return name;
}
public void setName(String name) {
	this.name = name;
}

}
