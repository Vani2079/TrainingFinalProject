package com.banking.app.service;

import java.util.Optional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.banking.app.dao.AccountRepository;
import com.banking.app.dto.BalanceRequestDto;
import com.banking.app.dto.BeneficiaryRequestDto;
import com.banking.app.dto.TransactionRequestDto;
import com.banking.app.exception.AccountNotFoundException;
import com.banking.app.model.Account;

@Service
public class AccountServiceImpl implements AccountService {

	@Autowired
	AccountRepository accountRepository;

	/* To save the account Details */
	@Override
	public void saveAccount(Account account) {
		accountRepository.save(account);

	}

	/* to get the account details */
	@Override
	public Account getAccount(Long id) {
		Optional<Account> account = accountRepository.findById(id);
		if (account.isPresent())
			return account.get();
		else
			return new Account();

	}

	/* to check for account details */
	@Override
	public int getAccount(String accountNumber) {
		Account a = accountRepository.findByaccountNumber(accountNumber);
		if (a != null)
			return 1;
		else
			return 0;

	}

	/* To check if the account is valid */
	@Override
	public void validateAccountNumber(TransactionRequestDto transactionRequestDto) {
		Account account = accountRepository.findByaccountNumber(transactionRequestDto.getToAccountNumber());
		if (account == null) {
			throw new AccountNotFoundException(
					"Invalid account number : " + transactionRequestDto.getToAccountNumber());
		}

	}

	/*
	 * to update the balance in account table and to check if available balance is
	 * greater then entered amount
	 */
	@Override
	public boolean updateBalance(double amount, String fromAccountNumber,String toAccountNumber) {
		Account fromaccount = accountRepository.findByaccountNumber(fromAccountNumber);
		Account toaccount = accountRepository.findByaccountNumber(toAccountNumber);
		float fromupdatBalance = 0;
		float toupdatBalance = 0;
		if (fromaccount.getBalance() > amount) {
			fromupdatBalance = (float) (fromaccount.getBalance() - amount);
			toupdatBalance =(float) (toaccount.getBalance()+amount);
			fromaccount.setBalance(fromupdatBalance);
			toaccount.setBalance(toupdatBalance);
			accountRepository.save(fromaccount);
			accountRepository.save(toaccount);

			return true;
		} else
			return false;

	}

	/* check for beneficiary account number is present in table */
	@Override
	public void validateBeneficiaryAccountNumber(BeneficiaryRequestDto beneficiaryRequestDto) {
		Account account = accountRepository.findByaccountNumber(beneficiaryRequestDto.getAccountNumber());
		if (account == null) {
			throw new AccountNotFoundException(
					"Invalid beneficiary number : " + beneficiaryRequestDto.getAccountNumber());
		}
	}

	/* update the balance from balance Request Dto */
	@Override
	public void updateAmount(BalanceRequestDto balanceRequestDto) {
		Account account = accountRepository.findByaccountNumber(balanceRequestDto.getAccountNumber());
		account.setBalance(balanceRequestDto.getBalance());
		accountRepository.save(account);
	}

}
