package com.banking.app.exception;

public class BeneficiaryAccountNotFoundException extends RuntimeException {
private static final long serialVersionUID=1L;
	
	public  BeneficiaryAccountNotFoundException(String exception)
	{
		super(exception);
	}

	
	
}
