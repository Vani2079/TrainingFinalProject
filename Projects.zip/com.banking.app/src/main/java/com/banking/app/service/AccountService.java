package com.banking.app.service;


import com.banking.app.dto.BalanceRequestDto;
import com.banking.app.dto.BeneficiaryRequestDto;
import com.banking.app.dto.TransactionRequestDto;
import com.banking.app.model.Account;

public interface AccountService {
	public void saveAccount(Account account);
	public Account getAccount(Long id);
	public int getAccount(String accountNumber);
	public void validateAccountNumber(TransactionRequestDto transactionRequestDto);
	
	public boolean updateBalance(double amount, String fromAccountNumber,String toAccountNumber);
	public void validateBeneficiaryAccountNumber(BeneficiaryRequestDto beneficiaryRequestDto);
	public void updateAmount(BalanceRequestDto balanceRequestDto);
}
