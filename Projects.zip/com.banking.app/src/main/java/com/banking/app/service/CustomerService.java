package com.banking.app.service;

import com.banking.app.dto.CustomerRequestDto;


public interface CustomerService {
	public void saveCustomer(CustomerRequestDto customerRequestDto);

	public String validate(String phone_no, String password);

}
