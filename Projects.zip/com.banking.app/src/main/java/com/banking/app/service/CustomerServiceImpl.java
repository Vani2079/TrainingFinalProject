package com.banking.app.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.banking.app.dao.AccountRepository;
import com.banking.app.dao.CustomerRepository;
import com.banking.app.dto.CustomerRequestDto;
import com.banking.app.model.Account;
import com.banking.app.model.Customer;


@Service
public class CustomerServiceImpl implements CustomerService {

	static Long customer_id = 1000L;
	static Long AccountNumber = 1000L;

	@Autowired
	CustomerRepository customerRepository;
	@Autowired
	AccountRepository accountRepository;

	/* To save the customer details in the table */
	@Override
	public void saveCustomer(CustomerRequestDto customerRequestDto) {
		Customer customer=new Customer();
		customer.setCustomer_id(customer_id++);
		customer.setAadhar(customerRequestDto.getAadhar());
		customer.setAddress(customerRequestDto.getAddress());
		customer.setDob(customerRequestDto.getDob());
		customer.setEmail(customerRequestDto.getEmail());
		customer.setName(customerRequestDto.getName());
		customer.setPassword(customerRequestDto.getPassword());
		customer.setPhone_no(customerRequestDto.getPhone_no());
		Account account = new Account();
		account.setBalance(0);
		AccountNumber++;
		account.setAccountNumber("IOB" + AccountNumber);
		account.setCustomer_id(customer.getCustomer_id());

		customerRepository.save(customer);
		accountRepository.save(account);
	}

	/* Login validation for the customer */
	@Override
	public String validate(String phone_no, String password) {
		String name = customerRepository.validateCustomer(phone_no, password);
		if (name == null) {
			return "login unsuccessful";
		}
		return "login Successful  Customer: " + name;
	}

}
