package com.banking.app.dao;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.banking.app.dto.CustomerRequestDto;
import com.banking.app.model.Customer;

@Repository
public interface CustomerRepository extends CrudRepository<Customer, Long> {
	@Query("select name from Customer where phone_no=?1 and password=?2")
	String validateCustomer(String phone_no, String password);

	void save(CustomerRequestDto customer);

}
