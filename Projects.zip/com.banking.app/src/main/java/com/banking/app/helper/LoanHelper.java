package com.banking.app.helper;

import java.util.ArrayList;
import java.util.List;


import org.springframework.stereotype.Component;

import com.banking.app.model.Loan;

@Component
public class LoanHelper {
	
	
	public List<Loan> getAmount(double calculatedAmount, List<Loan> loanDetails)
	{
		/*
		 * List<Loan> result = lines.stream() .filter(line -> !"mkyong".equals(line))
		 * .collect(Collectors.toList());
		 */   
		
		//List<Loan> result=loanDetails.stream().map((calculatedAmount)>30000).collect(Collectors.toList());
		 //E = P x r x (1 + r) ^ n / [(1 + r) ^ n - 1];
		List<Loan> list=new ArrayList<Loan>();
		for(Loan loan :loanDetails)
		{
			double rate=loan.getInterest()/12/100;
			double function=Math.pow((1+rate), (loan.getTenure()*12));
			double emiAmount=((loan.getPrinciple()*rate*function))/(function-1);
			if(emiAmount<calculatedAmount)
				list.add(loan);
				
		}
		
		return list;
		
	}

}
