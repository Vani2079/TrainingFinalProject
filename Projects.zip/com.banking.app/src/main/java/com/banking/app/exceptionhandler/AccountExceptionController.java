package com.banking.app.exceptionhandler;

import java.time.LocalDateTime;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;

import com.banking.app.exception.AccountNotFoundException;
import com.banking.app.exception.BeneficiaryAccountNotFoundException;

@ControllerAdvice
public class AccountExceptionController extends ResponseEntityExceptionHandler {
	
	@ExceptionHandler(AccountNotFoundException.class)
	public ResponseEntity<Error> handleEception(AccountNotFoundException exception)
	{
		Error error=new Error();
		error.setMessage(exception.getMessage());
		error.setStatus(HttpStatus.NOT_FOUND.value());
		error.setTimestamp(LocalDateTime.now());
		error.setSuggestion("Account Number is not valid! Please retry");
		return new ResponseEntity<Error>(error,HttpStatus.NOT_FOUND);
	}
	
	@ExceptionHandler(BeneficiaryAccountNotFoundException.class)
	public ResponseEntity<Error> handleEception(BeneficiaryAccountNotFoundException exception)
	{
		Error error=new Error();
		error.setMessage(exception.getMessage());
		error.setStatus(HttpStatus.NOT_FOUND.value());
		error.setTimestamp(LocalDateTime.now());
		error.setSuggestion("Beneficiary Account Number is not valid! Please add the payee");
		return new ResponseEntity<Error>(error,HttpStatus.NOT_FOUND);
	}

}
