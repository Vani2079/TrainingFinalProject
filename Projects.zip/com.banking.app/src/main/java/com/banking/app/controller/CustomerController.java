package com.banking.app.controller;



import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import com.banking.app.dto.BalanceRequestDto;
import com.banking.app.dto.CustomerRequestDto;
import com.banking.app.service.AccountService;
import com.banking.app.service.CustomerService;

@RestController
public class CustomerController {
	private final Logger logger = LoggerFactory.getLogger(CustomerController.class);
	@Autowired
	AccountService accountService;

	@Autowired
	CustomerService customerService;

	@PostMapping("/customers")
	public void saveCustomer(@RequestBody CustomerRequestDto customerRequestDto) {
		logger.info("Saving the details");
		customerService.saveCustomer(customerRequestDto);
		logger.info("saved");
	}

	@PostMapping("/customer")
	public String validate(@RequestParam String phone, @RequestParam String password) {
		return customerService.validate(phone, password);
	}

	@PatchMapping("/customers")
	public ResponseEntity<?> updateBalance(@RequestBody BalanceRequestDto balanceRequestDto) {

		accountService.updateAmount(balanceRequestDto);
		return ResponseEntity.ok("Balance updated!");
	}
	
}
