package com.banking.app.dao;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.banking.app.model.Transaction;

@Repository
public interface TransactionRepository extends CrudRepository<Transaction,Integer> {

}


