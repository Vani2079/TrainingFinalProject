package com.banking.app.service;

import java.util.Optional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.banking.app.dao.BeneficaryRepository;
import com.banking.app.dto.BeneficiaryRequestDto;
import com.banking.app.exception.BeneficiaryAccountNotFoundException;
import com.banking.app.model.AccountNumberBenificiaryNumber;
import com.banking.app.model.Beneficiary;

@Service
public class BeneficaryServiceImpl implements BeneficaryService {

	@Autowired
	BeneficaryRepository beneficaryRepository;

	/* To save the beneficiary details in the table */
	@Override
	public void saveBeneficary(BeneficiaryRequestDto beneficiaryRequestDto) {
		Beneficiary beneficiary = new Beneficiary();
		AccountNumberBenificiaryNumber accountNumberBeneficiaryNumber = new AccountNumberBenificiaryNumber();
		System.out.println(beneficiaryRequestDto.getAccountNumber());
		accountNumberBeneficiaryNumber.setAccountNumber(beneficiaryRequestDto.getAccountNumber());
		accountNumberBeneficiaryNumber.setBenificiaryAccountNumber(beneficiaryRequestDto.getBeneficiaryNumber());
		beneficiary.setName(beneficiaryRequestDto.getName());
		beneficiary.setAccountNumberBenificiaryNumber(accountNumberBeneficiaryNumber);
		beneficaryRepository.save(beneficiary);

	}

	/* check if the beneficiary is present before transaction */
	@Override
	public void BeneficiaryAccountNumber(String toAccountNumber, String fromAccountNumber) {
		// beneficaryRepository.findById(toAccountNumber);
		AccountNumberBenificiaryNumber accountNumberBeneficiaryNumber = new AccountNumberBenificiaryNumber();
		accountNumberBeneficiaryNumber.setAccountNumber(fromAccountNumber);
		accountNumberBeneficiaryNumber.setBenificiaryAccountNumber(toAccountNumber);
		Optional<Beneficiary> beneficiary = beneficaryRepository.findById(accountNumberBeneficiaryNumber);

		if (!(beneficiary.isPresent())) {
			throw new BeneficiaryAccountNotFoundException("Invalid beneficiary number : " + toAccountNumber);
		}

	}
}
