package com.banking.app.dao;


import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.banking.app.model.Account;

@Repository
public interface AccountRepository extends CrudRepository<Account,Long> {

	Account findByaccountNumber(String accountNumber);
	

}
