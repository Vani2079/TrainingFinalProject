package com.banking.app.model;

import javax.persistence.Entity;

import javax.persistence.Id;

@Entity
public class Loan {
@Id
private long id;
public long getId() {
	return id;
}
public void setId(long id) {
	this.id = id;
}
public long getPrinciple() {
	return principle;
}
public void setPrinciple(long principle) {
	this.principle = principle;
}
public float getInterest() {
	return interest;
}
public void setInterest(float interest) {
	this.interest = interest;
}
public float getTenure() {
	return tenure;
}
public void setTenure(float tenure) {
	this.tenure = tenure;
}
private long principle;
private float interest;
private float tenure;
}
