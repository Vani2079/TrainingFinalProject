package Model;

import javax.persistence.EmbeddedId;
import javax.persistence.Entity;

@Entity
public class Screen {
	@EmbeddedId
	compositeKey ScreenNoTheatreId;
	private long mornShow;
	private long noonShow;
	private long eveShow;
	public compositeKey getScreenNoTheatreId() {
		return ScreenNoTheatreId;
	}
	public void setScreenNoTheatreId(compositeKey screenNoTheatreId) {
		ScreenNoTheatreId = screenNoTheatreId;
	}
	public long getMornShow() {
		return mornShow;
	}
	public void setMornShow(long mornShow) {
		this.mornShow = mornShow;
	}
	public long getNoonShow() {
		return noonShow;
	}
	public void setNoonShow(long noonShow) {
		this.noonShow = noonShow;
	}
	public long getEveShow() {
		return eveShow;
	}
	public void setEveShow(long eveShow) {
		this.eveShow = eveShow;
	}

}
