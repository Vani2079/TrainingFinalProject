package Model;

import java.io.Serializable;

import org.springframework.stereotype.Component;

@Component
public class compositeKey implements Serializable {
	
	private static final long serialVersionUID = 1L;
	
	private long theatreId;
	private int ScreenNo;
	public long getTheatreId() {
		return theatreId;
	}
	public void setTheatreId(long theatreId) {
		this.theatreId = theatreId;
	}
	public int getScreenNo() {
		return ScreenNo;
	}
	public void setScreenNo(int screenNo) {
		ScreenNo = screenNo;
	}
	

}
