package controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;

import Model.User;

@Controller
public class MovieController {
	
	@RequestMapping("/user")
	public String display(Model model)
	{
		User user=new User();
		model.addAttribute("userDetails",user);
		return "Registration";
	}
	@RequestMapping("/login")
	public String display(@ModelAttribute("UserDetails") User ur,Model m)
	{
		//s.addDetails(ur);
		return "login";
		
	}

}
