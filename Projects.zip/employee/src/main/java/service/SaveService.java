package service;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;

import Model.EmpModel;


public class SaveService {
	@Autowired
	private SessionFactory sessionFactory;
	
	public void save( EmpModel ee)
	{
		Session session = sessionFactory.openSession();
	      Transaction tx = null;
	    
	      
	      try {
	         tx = session.beginTransaction();
	         
	         session.save(ee);
	         
	       // session.getTransaction().commit();
	         tx.commit();
	        //Save the employee in database
	       
	        
	         
		
	}catch(Exception e)
	      {
		e.printStackTrace();
	      }finally {
	    	  session.close();
	      }
	     

	}
	public List<EmpModel> homeDisplay()
	{
		Session session = sessionFactory.openSession();
	      Transaction tx = null;
	      List<EmpModel>user = null;
	      List<EmpModel>uuu=new ArrayList<EmpModel>();
	      
	     // Hotel us=new Hotel();
	      try {
	         tx = session.beginTransaction();
	         user= session.createQuery("FROM EmpModel").list(); 
	        for(EmpModel u:user)
	        {
	        	
	        		uuu.add(u);
	        	}
	        
	         
	      } catch (HibernateException e) {
	         if (tx!=null) tx.rollback();
	         e.printStackTrace(); 
	      } finally {
	         session.close(); 
	      }
		
	return uuu;
	

	
		
		
		
	}

}
