package controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;

import Model.EmpModel;
import service.SaveService;



@Controller
public class EmployeeController {
	@Autowired
	 SaveService s;
	
	@RequestMapping("/emp")
	public String disp(Model m)
	{
		EmpModel em=new EmpModel();
		m.addAttribute("employee", em);
		return "emp";
	}
	
	@RequestMapping("/home")
	public String disp1(@ModelAttribute("employee") EmpModel ee,Model m)
	{
		
		s.save(ee);
		List<EmpModel> list=new ArrayList<EmpModel>();
		list=s.homeDisplay();
		m.addAttribute("emp", list);
		return "home";
	}

}
