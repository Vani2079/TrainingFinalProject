package com.company.IpRepository;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class IpRepositoryApplicationTests {

	@Test
	void contextLoads() {
	}

}
