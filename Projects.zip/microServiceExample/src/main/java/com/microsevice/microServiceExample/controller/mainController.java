package com.microsevice.microServiceExample.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import com.microsevice.microServiceExample.model.Employee;

@RestController
public class mainController {
	@Autowired
	RestTemplate restTemplate;
	
	@GetMapping("/employees")
	public List<Employee> getEmployees()
	{
		List<Employee> list=new ArrayList<Employee>();
		return 	restTemplate.getForObject("http://CARPARKING/salary?salary=50000",List.class);
		
		
	}
	
	@GetMapping("/loan")
	public List<Employee> getLoan()
	{
		List<Employee> list=new ArrayList<Employee>();
		return 	restTemplate.getForObject("http://localhost:8081/loan?amount=50000",List.class);
		
		
	}
	
	/*
	 * @PatchMapping("/update") public String updatePhone(@RequestParam("phone")
	 * String phone,@RequestParam("SapId") Long sapId) { //return
	 * restTemplate.patchForObject("http://CARPARKING/update?sapId=10001"+
	 * "?phone=67677",List.class); }
	 */
	

}
