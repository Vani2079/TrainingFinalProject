package service;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;

import Model.BookedHotels;
import Model.CompKey;
import Model.Hotel;
import Model.User;




public class UserService {
	
		
		@Autowired
		private SessionFactory sessionFactory;
		
		public void addDetails(User ur)  {
			
			
			
		      Session session = sessionFactory.openSession();
		      Transaction tx = null;
		    
		      
		      try {
		         tx = session.beginTransaction();
		         
		         session.save(ur);
		         
		       // session.getTransaction().commit();
		         tx.commit();
		        //Save the employee in database
		       
		        
		         
			
		}catch(Exception e)
		      {
			e.printStackTrace();
		      }finally {
		    	  session.close();
		      }
		     

	}
		public User getUser(String email,String password)
		{
			 Session session = sessionFactory.openSession();
		      Transaction tx = null;
		      List<User>user = null;
		      
		      User us=new User();
		      try {
		         tx = session.beginTransaction();
		         user= session.createQuery("FROM User").list(); 
		        for(User u:user)
		        {
		        	if(u.getEmail().equals(email) && (u.getPassword().equals(password)))
		        	{
		        		us=u;
		        	}
		        }
		         
		      } catch (HibernateException e) {
		         if (tx!=null) tx.rollback();
		         e.printStackTrace(); 
		      } finally {
		         session.close(); 
		      }
			
		return us;
		
	
		
			
			
		}
		public List<Hotel> getHotels() {
			Session session = sessionFactory.openSession();
		      Transaction tx = null;
		      List<Hotel>user = null;
		      List<Hotel>uuu=new ArrayList<Hotel>();
		      
		      Hotel us=new Hotel();
		      try {
		         tx = session.beginTransaction();
		         user= session.createQuery("FROM Hotel").list(); 
		        for(Hotel u:user)
		        {
		        	
		        		uuu.add(u);
		        	}
		        
		         
		      } catch (HibernateException e) {
		         if (tx!=null) tx.rollback();
		         e.printStackTrace(); 
		      } finally {
		         session.close(); 
		      }
			
		return uuu;
		
	
		
			
			
			
		}
		public Hotel getHotelDetails(String name) {
			Session session = sessionFactory.openSession();
		      Transaction tx = null;
		      List<Hotel>user = null;
		      Hotel uuu=new Hotel();
		      
		      Hotel us=new Hotel();
		      try {
		         tx = session.beginTransaction();
		         user= session.createQuery("FROM Hotel").list(); 
		        for(Hotel u:user)
		        {
		        	if(name.equals(u.getName()))
		        	{
		        		uuu=u;
		        	}
		        	}
		        
		         
		      } catch (HibernateException e) {
		         if (tx!=null) tx.rollback();
		         e.printStackTrace(); 
		      } finally {
		         session.close(); 
		      }
			
		return uuu;
			
		}
		public BookedHotels bookhotel(Date checkin, Date checkout, String name, long amount, String email, String hotelName) {
			BookedHotels b=new BookedHotels();
			CompKey emailCheckinDate = new CompKey();
			emailCheckinDate.setCheckin(checkin);
			emailCheckinDate.setEmail(email);
			b.setCk(emailCheckinDate);
			b.setCheckout(checkout);
		//	b.getCk().setEmail(email);
			b.setHotelName(hotelName);
			//System.out.println(b.getAmount());
			long days=checkout.getDate()-checkin.getDate();
			b.setAmount(amount*days);
			//System.out.println(days);
			
			 Session session = sessionFactory.openSession();
		      Transaction tx = null;
		    
		      
		      try {
		         tx = session.beginTransaction();
		         
		         session.save(b);
		         
		       // session.getTransaction().commit();
		         tx.commit();
		        //Save the employee in database
		       
		        
		         
			
		}catch(Exception e)
		      {
			e.printStackTrace();
		      }finally {
		    	  session.close();
		      }
			return b;
		     
			
		}
		public List<Hotel> searchByLocation(String name) {
			
			Session session = sessionFactory.openSession();
		      Transaction tx = null;
		      List<Hotel>user = null;
		      List<Hotel>uuu=new ArrayList<Hotel>();
		      
		      Hotel us=new Hotel();
		      try {
		         tx = session.beginTransaction();
		         user= session.createQuery("FROM Hotel").list(); 
		         
		        for(Hotel u:user)
		        {
		        	if(name.equalsIgnoreCase(u.getPlace())) {
		        	
		        		uuu.add(u);
		        	}
		        
		        }  
		      } catch (HibernateException e) {
		         if (tx!=null) tx.rollback();
		         e.printStackTrace(); 
		      } finally {
		         session.close(); 
		      }
			
		return uuu;
		
		}
		public int check(String email, String password) {
			int res=0;
			 Session session = sessionFactory.openSession();
		      Transaction tx = null;
		      List<User>user = null;
		      
		      User us=new User();
		      try {
		         tx = session.beginTransaction();
		         user= session.createQuery("FROM User").list(); 
		        for(User u:user)
		        {
		        	if(u.getEmail().equals(email) && (u.getPassword().equals(password)))
		        	{
		        		res=1;
		        	}
		        }
		         
		      } catch (HibernateException e) {
		         if (tx!=null) tx.rollback();
		         e.printStackTrace(); 
		      } finally {
		         session.close(); 
		      }
			
		
			return res;
		}
		public int checkBookedHotels(BookedHotels b) {
			int res=0;
			 Session session = sessionFactory.openSession();
		      Transaction tx = null;
		      List<BookedHotels>user = null;
		      
		     // User us=new User();
		      try {
		         tx = session.beginTransaction();
		         user= session.createQuery("FROM BookedHotels").list(); 
		        for(BookedHotels u:user)
		        {
		        	if(b.getCk().getEmail().equalsIgnoreCase(u.getCk().getEmail()))
		        	{
		        		if(b.getCk().getCheckin().equals(u.getCk().getCheckin()))
		        		res=1;
		        		break;
		        	}
		        }
		         
		      } catch (HibernateException e) {
		         if (tx!=null) tx.rollback();
		         e.printStackTrace(); 
		      } finally {
		         session.close(); 
		      }
			
		
			
			return res;
		}
		
			
		
			
		
		public int checkBookedHotels(Date checkin, String email) {
			// TODO Auto-generated method stub
			int res=0;
			 Session session = sessionFactory.openSession();
		      Transaction tx = null;
		      List<BookedHotels>user = null;
		      
		     // User us=new User();
		      try {
		         tx = session.beginTransaction();
		         user= session.createQuery("FROM BookedHotels").list(); 
		         
		        for(BookedHotels u:user)
		        {
		        	if(u.getCk().getEmail().equalsIgnoreCase(email))
		        	{
		        		if(u.getCk().getCheckin().compareTo(checkin)==0)
		        		res=1;
		        		break;
		        	}
		        }
		         
		      } catch (HibernateException e) {
		         if (tx!=null) tx.rollback();
		         e.printStackTrace(); 
		      } finally {
		         session.close(); 
		      }
			
		
			
			return res;
		}
		
	

}

	

	

