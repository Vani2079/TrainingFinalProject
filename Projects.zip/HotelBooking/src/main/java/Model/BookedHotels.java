package Model;

import java.util.Date;

import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class BookedHotels {

	
	
@EmbeddedId
CompKey emailCheckinDate;
//private String email;
private String hotelName;
//private Date checkin;
private Date checkout;
private long amount;

public String getHotelName() {
	return hotelName;
}
public void setHotelName(String hotelName) {
	this.hotelName = hotelName;
}

public CompKey getCk() {
	return emailCheckinDate;
}
public void setCk(CompKey emailCheckinDate) {
	this.emailCheckinDate = emailCheckinDate;
}
public Date getCheckout() {
	return checkout;
}
public void setCheckout(Date checkout) {
	this.checkout = checkout;
}
public long getAmount() {
	return amount;
}
public void setAmount(long amount) {
	this.amount = amount;
}

}
