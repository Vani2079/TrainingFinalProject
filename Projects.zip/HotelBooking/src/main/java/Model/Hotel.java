package Model;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class Hotel {
@Id
private String name;
private String place;
private long amount;
public String getName() {
	return name;
}
public void setName(String name) {
	this.name = name;
}
public String getPlace() {
	return place;
}
public void setPlace(String place) {
	this.place = place;
}
public long getAmount() {
	return amount;
}
public void setAmount(long amount) {
	this.amount = amount;
}
}
