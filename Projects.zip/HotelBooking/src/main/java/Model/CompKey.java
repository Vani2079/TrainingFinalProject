package Model;

import java.io.Serializable;
import java.util.Date;

import org.springframework.stereotype.Component;
@Component
public class CompKey implements Serializable {
	private static final long serialVersionUID=1L;
	 public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public Date getCheckin() {
		return checkin;
	}
	public void setCheckin(Date checkin) {
		this.checkin = checkin;
	}
	private String email;
	 private Date checkin;
	
	

}
