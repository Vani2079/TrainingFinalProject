package controller;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import Model.BookedHotels;
import Model.Hotel;
import Model.User;

import service.UserService;


@Controller
public class UserController {
	@Autowired
	 UserService s;
	
	@RequestMapping("/user")
	public String display(Model model)
	{
		User u=new User();
		model.addAttribute("userDetails",u);
		
		return "user";
	}
	@RequestMapping("/login")
	public String display(@ModelAttribute("UserDetails") User ur,Model m)
	{
		s.addDetails(ur);
		return "login";
		
	}
	@RequestMapping("/log")
	public String display1()
	{
		
		return "LoginAgain";
		
	}
	@RequestMapping("/loginform")
	public String display2(@RequestParam("email") String email,@RequestParam("password") String password,Model m,HttpServletRequest request)
	{
		int res=s.check(email,password);
		if(res==0) {
			return "LoginAgain";
		}else {
		 User u=s.getUser(email, password);
		request.getSession().setAttribute("user", u);
		
		List<Hotel> h= s.getHotels();
		
		m.addAttribute("hotels", h);
		
		return "home";
		}
	}
	@RequestMapping("/viewDetails")
	public String display3(@RequestParam("name1") String name,Model m)
	{
		Hotel h=s.getHotelDetails(name);
		//List<Hotel> hh=new ArrayList<Hotel>();
		//hh.add(h);
		m.addAttribute("l",h);
		return "hotelDetails";
		
	}
	
	@RequestMapping("/check")
	public String display4(@RequestParam("checkin") @DateTimeFormat(pattern="yyyy-MM-dd") Date checkin,@RequestParam("checkout")@DateTimeFormat(pattern="yyyy-MM-dd") Date checkout,@RequestParam("nn") String name
			,@RequestParam("amount") long amount,HttpSession session,Model m)
	{
		User u=(User) session.getAttribute("user");
		int bb=s.checkBookedHotels(checkin,u.getEmail());
		if(bb==0) {
		BookedHotels b=s.bookhotel(checkin,checkout,name,amount,u.getEmail(),name);
		m.addAttribute("details", b);
		
		return "booked";
		
		}
		return "unsuccessful";
	}
	@RequestMapping("/search")
	public String display5(@RequestParam("name") String name,Model m)
	{
		List<Hotel> h=s.searchByLocation(name);
		m.addAttribute("hotels",h);
		return "home";
		
	}
}
