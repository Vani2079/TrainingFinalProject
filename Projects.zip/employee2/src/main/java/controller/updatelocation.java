package controller;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import model.Employee;
import model.Organisation;
import model.userCredentials;
import service.validateuser;

@Controller
public class updatelocation {
	@Autowired
	validateuser uv;
	@RequestMapping("/updateLocation")
	public String display()
	{
		return "updateLoc";
		
	}
	
	@RequestMapping("/update")
	public String disp(@RequestParam("updateloc") String loc,@RequestParam("sapid") String sapid)
	{
		int check=uv.updateLocation(loc,sapid);
		System.out.println(loc);
		if(check>0) {
		return "updatedLocation";
		}
		else return "updateLoc";

}
	@RequestMapping("/updateEmail")
	public String display1()
	{
		return "updateMail";
		
	}
	@RequestMapping("/updateM")
	public String display2(@RequestParam("email") String email,HttpSession session)
	{
		
		Employee em = (Employee) session.getAttribute("emp");
		int res=uv.updateEmail(em,email);
		if(res>0) {
		  
		return "UpdatedMail";
		}
		else return "upMail";
	}
	@RequestMapping("/profile")
	public String display3(HttpSession session,Model m,HttpServletRequest request)
	{
		
		userCredentials u=(userCredentials) session.getAttribute("name");
		System.out.println(u.getUsername());
		Organisation o=uv.profileDetails(u);
		Employee ee=uv.Profile(o.getSapId());
		request.getSession().setAttribute("emp", ee);
		System.out.println(ee.getSapId());
		List<Employee> emp=new ArrayList<Employee>();
		emp.add(ee);
		m.addAttribute("emp",emp);
		return "displayprofile";
}
	@RequestMapping("/rm")
	public String display4()
	{
		return "RmLogin";
	}
	@RequestMapping("/rmlogin1")
	public String display5(@RequestParam("rmuser") String rmuser,Model m,HttpServletRequest request)
	{
		List<Employee> l1=new ArrayList<Employee>();
		//List<Employee> l2=new ArrayList<Employee>();
		List<Employee> ee=new ArrayList<Employee>();
		ee=uv.getEmployee(rmuser);
		request.getSession().setAttribute("emp", ee);
		
		//Employee em = (Employee) session.getAttribute("emp",);
		//l1=uv.checkRm(ee,rmuser);
		for(Employee s:ee)
		{
			System.out.println(s.getName());
		}
		
		
		
		m.addAttribute("emp",ee);
		return "page";
	}
}