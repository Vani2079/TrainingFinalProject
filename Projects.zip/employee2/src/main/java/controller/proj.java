package controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;

import model.Employee;
import service.getComapyDetails;
import service.getProjectDetails;

@Controller
public class proj {
	
	@Autowired
	private getProjectDetails projectDetails;
	@RequestMapping("/proj")
	public String method(@ModelAttribute("UserDetails") Employee emp,Model m)
	{
				
		
		model.project p1= projectDetails.getprojectDet(emp);
		
		List< model.project> pD=new ArrayList< model.project>();
	    pD.add(p1);
	    m.addAttribute("proje",pD);
	    System.out.println(p1.getSapId());
		return "project";
	}

}
