package controller;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import model.Employee;
import model.userCredentials;

@Controller
public class UserController {
	@RequestMapping("/user")
	public String display(Model model,HttpSession session,HttpServletRequest request)
	{
		userCredentials u=new userCredentials();
		model.addAttribute("userCred",u);
		//List<Employee> ee=new ArrayList<Employee>();
		
		
			 return "user";
		
		
	}

}
