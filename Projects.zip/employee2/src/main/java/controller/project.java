package controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;

import model.Employee;
import model.Organisation;
import service.getProjectDetails;

@Controller
public class project {
	@Autowired
	private getProjectDetails projectDetails;
	
	
	
@RequestMapping("/project")
public String display(@ModelAttribute("UserDetails") Employee emp,Model m)
{
	//project p1=new project();
	//p1=projectDetails.projectDet(emp);
	
	 // model.project p1= projectDetails.getprojectDet(emp);
	//project proj=projectDetails.getCompDetails(emp);
	//projectDetails.projectDet(emp);
	
	//List<project> l1=new ArrayList<project>();
	//l1.add(p1);
	  List< model.project> pD=new ArrayList< model.project>();
	    //pD.add(p1);
	   // m.addAttribute("projectLi",pD);
	    return "project";
	
}
}
