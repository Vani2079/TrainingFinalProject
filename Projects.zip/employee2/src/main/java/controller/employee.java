package controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;



import model.Employee;



@Controller
public class employee {
	
	@RequestMapping("/employee")
	public String display(Model model)
	 {
		Employee u=new Employee();
		model.addAttribute("UserDetails",u);
		
		return "employee";
	 }
	


}
