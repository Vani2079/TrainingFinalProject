package controller;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import model.Employee;
import model.Organisation;
import service.getComapyDetails;
import service.getEmpImpl;
import service.getProjectDetails;
@Controller
public class organisation {
	@Autowired
	private getProjectDetails projectDetails;
	
	@Autowired 
	private getEmpImpl get;
	
	@Autowired 
	private  getComapyDetails CompanyDetails;
	
		@RequestMapping("/organisation")
		public String display(@ModelAttribute("UserDetails") Employee emp,Model m)
		 {
			
			System.out.println(emp.getSapId());
			System.out.println(emp.getAge());
			System.out.println(emp.getPhone());
			System.out.println(emp.getMailId());
			System.out.println(emp.getDob());
			//getEmpImpl get=new getEmpImpl();
		//	emp.setDob(LocalDate.parse(emp.getDob()));
			get.setDetails(emp);
			Organisation oo=new Organisation();
			Organisation or=CompanyDetails.getCompDetails( emp,oo);
			System.out.println(or.getSalary());
			System.out.println(or.getPassword());
			System.out.println(or.getRm());
			System.out.println(or.getUsername());
			System.out.println(or.getSapId());
			//addDetails(or);
			
			List<Organisation> list=new ArrayList<Organisation>();
			list.add(or);
		    m.addAttribute("lists", list);
		    
		   // project p=new project();
		   model.project p1= projectDetails.getprojectDet(emp);
		   System.out.println(p1.getProj_name());
		   System.out.println(p1.getLocation());
		   System.out.println(p1.getProject_Id());
		   System.out.println(p1.getSapId());
		    List< model.project> pD=new ArrayList< model.project>();
		    pD.add(p1);
		    m.addAttribute("projectList",pD);
			return "organisation";
		 }

		


	}


