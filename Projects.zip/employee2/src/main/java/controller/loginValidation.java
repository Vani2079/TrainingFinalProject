package controller;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;

import model.Organisation;
import model.userCredentials;
import service.validateuser;

@Controller
public class loginValidation {
	@Autowired
	validateuser uv;
	
	@RequestMapping("/loginValidation")
	public String display(@ModelAttribute("userCred") userCredentials u,Model m,HttpServletRequest request )
	
	{
		request.getSession().setAttribute("name", u);
		
		System.out.println(u.getUsername());
		System.out.println(u.getPassword());
		
		Organisation o=uv.validate(u);
		System.out.println(o.getSalary());
		List<Organisation> l1=new ArrayList<Organisation>();
		l1.add(o);
		
		 m.addAttribute("list", l1);
		 
		String sapid=o.getSapId();
		 List< model.project> pD=new ArrayList< model.project>();
		 
		
		 model.project pro=uv.validatepro(sapid);
		pD.add(pro);
		m.addAttribute("lists",pD);
		
		return "login";
}
}
