package DAO;




import java.time.LocalDate;

import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.RequestParam;

import model.Employee;



public class empImpl {
	static int a=111;
	@Autowired
	private SessionFactory sessionFactory;
	
	public void addDetails(Employee e1) {
		
		
		
	      Session session = sessionFactory.openSession();
	      Transaction tx = null;
	     // List<Employee> emp = null;
	      
	      String  p="HCL"+a++;
	      e1.setSapId(p);
	      
	      try {
	         tx = session.beginTransaction();
	         
	         session.save(e1);
	         
	       // session.getTransaction().commit();
	         tx.commit();
	        //Save the employee in database
	       
	        
	         
		
	}catch(Exception e)
	      {
		e.printStackTrace();
	      }finally {
	    	  session.close();
	      }
	     

}
}
//emp1 = session.createQuery("FROM vani").list(); 

//Employee emp1 = new Employee();
//  e1.setName("vani");
//  e1.setAge(20);
// e1.setDob(LocalDate.parse("20-10-2019"));
// e1.setPhone("1234677");
// e1.setMailId("vani@gmail.com");
// e1.setSapId("1223");
