package model;

import javax.persistence.Entity;
import javax.persistence.Id;
@Entity
public class project {
	private String project_Id;
	private String proj_name;
	private String location;
	@Id
	private String sapId;
	public String getProject_Id() {
		return project_Id;
	}
	public void setProject_Id(String project_Id) {
		this.project_Id = project_Id;
	}
	public String getProj_name() {
		return proj_name;
	}
	public void setProj_name(String proj_name) {
		this.proj_name = proj_name;
	}
	public String getLocation() {
		return location;
	}
	public void setLocation(String location) {
		this.location = location;
	}
	public String getSapId() {
		return sapId;
	}
	public void setSapId(String sapId) {
		this.sapId = sapId;
	}
	
	
	

}
