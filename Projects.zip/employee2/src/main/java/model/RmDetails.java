package model;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class RmDetails {

	@Id
	private String empSapId;
	public String getEmpSapId() {
		return empSapId;
	}
	public void setEmpSapId(String empSapId) {
		this.empSapId = empSapId;
	}
	public String getRmSapId() {
		return rmSapId;
	}
	public void setRmSapId(String rmSapId) {
		this.rmSapId = rmSapId;
	}
	private String rmSapId;
	
	
}
