package service;

import java.util.List;

import model.Employee;

public interface getEmp {
	public void setDetails( Employee emp1);
}
