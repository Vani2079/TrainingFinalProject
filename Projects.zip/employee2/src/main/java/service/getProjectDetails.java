package service;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import model.Employee;
import model.Organisation;
import model.project;

@Service
public class getProjectDetails {
	
	
	project p=new project();
	Random r=new Random();
	public project getprojectDet1(Employee e)
	{
	// project_Id
	p.setProject_Id("1231");
	p.setLocation("Bangalore");
	
	String sap=e.getSapId();
	p.setSapId(sap);
	//	private String proj_name;
	//	private String location;
		return p;
		
	}
	static int a=111;
	@Autowired
	private SessionFactory sessionFactory;
	
	public void addDetails(project e1,Employee e) {
		
		
		
	      Session session = sessionFactory.openSession();
	      Transaction tx = null;
	     // List<Employee> emp = null;
	      
	      String  p="HCL"+a++;
	      e1.setSapId(e.getSapId());
	      
	      try {
	         tx = session.beginTransaction();
	         
	         session.save(e1);
	       // session.getTransaction().commit();
	         tx.commit();
	        //Save the employee in database
	       
	        
	         
		
	}catch(Exception ex)
	      {
		ex.printStackTrace();
	      }finally {
	    	  session.close();
	      }
	     

}

	public project getprojectDet(Employee emp) {
		// TODO Auto-generated method stub
		
		
		List<String> list = new ArrayList<>(); 
	    // add 5 element in ArrayList 
	    list.add("bangalore"); 
	    list.add("Mumbai"); 
	    list.add("delhi"); 
	    

	    getProjectDetails obj = new getProjectDetails(); 

	    // take a random element from list and print them 
	    System.out.println(obj.getRandomElement(list)); 
	
		p.setProject_Id("1231");
		p.setLocation(obj.getRandomElement(list));
		p.setSapId(emp.getSapId());
		p.setProj_name("spring Hibernate");
		addDetails(p,emp);
		return p;
	}
	
	

// Function select an element base on index  
// and return an element 
public String getRandomElement(List<String> list) 
{ 
    Random rand = new Random(); 
    return list.get(rand.nextInt(list.size())); 
} 
} 



