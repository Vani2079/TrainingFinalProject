package service;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;

import model.Employee;
import model.Organisation;
import model.RmDetails;
import model.project;
import model.userCredentials;



public class validateuser {
	@Autowired
	private SessionFactory sessionFactory;

	public Organisation validate(userCredentials u)
	{
		
		      Session session = sessionFactory.openSession();
		      Transaction tx = null;
		      List<Organisation>org = null;
		      
		      Organisation o=new Organisation();
		      try {
		         tx = session.beginTransaction();
		        org= session.createQuery("FROM Organisation").list(); 
		        for(Organisation or:org)
		        {
		        	if(u.getUsername().equals(or.getUsername()))
		        	{
		        		o=or;
		        	}
		        }
		         
		      } catch (HibernateException e) {
		         if (tx!=null) tx.rollback();
		         e.printStackTrace(); 
		      } finally {
		         session.close(); 
		      }
			
		return o;
		
	}
	public project validatepro(String sapid)
	{
		Session session = sessionFactory.openSession();
	      Transaction tx = null;
	      List<project>proje = null;
	      
	      project pp=new project();
	      try {
	         tx = session.beginTransaction();
	        proje= session.createQuery("FROM project").list(); 
	        for(project pppp:proje)
	        {
	        	if(sapid.equals(pppp.getSapId()))
	        	{
	        		pp=pppp;
	        	}
	        }
	         
	      } catch (HibernateException e) {
	         if (tx!=null) tx.rollback();
	         e.printStackTrace(); 
	      } finally {
	         session.close(); 
	      }
		
	return pp;
		
		
		
	}
	
	public int updateLocation(String loc,String sapid)
	{
		int result=0;
		Session session = sessionFactory.openSession();
	      Transaction tx = null;
	      List<project>proje = null;
	      proje= session.createQuery("FROM project").list(); 
	      project pp=new project();
	      try {
	         tx = session.beginTransaction();
	       // proje= session.createQuery("FROM project").list(); 
	        for(project p:proje)
	       if(sapid.equals(p.getSapId()))
	       {
	    	   p.setLocation(loc);
	    	   session.update(p);
	  	     
		         tx.commit();
	    	   result=1;
	       }
	       
	        // result = query.executeUpdate();
	       // System.out.println("Rows affected: " + result);
	       
	         
	      } catch (HibernateException e) {
	         if (tx!=null) tx.rollback();
	         e.printStackTrace(); 
	      } finally {
	         session.close(); 
	      }
		return result;
		
	}
	public Organisation profileDetails(userCredentials u)
	{
		Session session = sessionFactory.openSession();
	      Transaction tx = null;
	      List<Organisation>org = null;
	      
	      Organisation o=new Organisation();
	      try {
	         tx = session.beginTransaction();
	        org= session.createQuery("FROM Organisation").list(); 
	        for(Organisation or:org)
	        {
	        	if(u.getUsername().equals(or.getUsername()))
	        	{
	        		o=or;
	        	}
	        }
	         
	      } catch (HibernateException e) {
	         if (tx!=null) tx.rollback();
	         e.printStackTrace(); 
	      } finally {
	         session.close(); 
	      }
		return o;
		
	}
	public Employee Profile(String sapId) {
		Session session = sessionFactory.openSession();
	      Transaction tx = null;
	      List<Employee>emp = null;
	      
	      Employee o=new Employee();
	      try {
	         tx = session.beginTransaction();
	        emp= session.createQuery("FROM Employee").list(); 
	        for(Employee or:emp)
	        {
	        	if(sapId.equals(or.getSapId()))
	        	{
	        		o=or;
	        	}
	        }
	         
	      } catch (HibernateException e) {
	         if (tx!=null) tx.rollback();
	         e.printStackTrace(); 
	      } finally {
	         session.close(); 
	      }
		return o;
	}
	public int updateEmail(Employee em, String email) {
		
		int result=0;
		Session session = sessionFactory.openSession();
	      Transaction tx = null;
	      List<Employee>emp = null;
	    //  emp= session.createQuery("FROM Employee").list(); 
	     // Employee e=new Employee();
	      try {
	         tx = session.beginTransaction();
	       // proje= session.createQuery("FROM project").list(); 
	      //  for(Employee emp1:emp)
	      
	    	   em.setMailId(email);
	    	   session.update(em);
		  	     
		        
		         tx.commit();
	    	   result=1;
	       
	       
	        // result = query.executeUpdate();
	       // System.out.println("Rows affected: " + result);
	       
	         
	      } catch (HibernateException e4) {
	         if (tx!=null) tx.rollback();
	         e4.printStackTrace(); 
	      } finally {
	         session.close(); 
	      }
		return result;
		
	}
	public List<Employee > checkRm(Employee em, String rmuser) {
		Session session = sessionFactory.openSession();
	      Transaction tx = null;
	      List<RmDetails>rm = null;
	      List<Employee> l1=new ArrayList<Employee>();
	     // RmDetails o=new RmDetails();
	      try {
	         tx = session.beginTransaction();
	        rm= session.createQuery("FROM RmDetails").list();
	      //  System.out.println(rm.isEmpty());
	        
	        for(RmDetails r:rm)
	        {
	        	if(rmuser.equals(r.getRmSapId()))
	        	{
	        		l1.add(em);
	        	}
	        }
	         
	      } catch (HibernateException e) {
	         if (tx!=null) tx.rollback();
	         e.printStackTrace(); 
	      } finally {
	         session.close(); 
	      }
		return l1;
		
	}
	public List<Employee> getEmployee(String rmuser) {
		
		Session session = sessionFactory.openSession();
	      Transaction tx = null;
	      List<Organisation>org = new ArrayList<Organisation>();
	      List<Employee> emp=new ArrayList<Employee>();
	      List<Organisation> org1=new ArrayList<Organisation>();
	      List<Employee> eee=new ArrayList<Employee>();
	      Employee eeee=new Employee();
	      
	      Organisation o=new Organisation();
	      try {
	         tx = session.beginTransaction();
	         org= session.createQuery("FROM Organisation").list(); 
	        for(Organisation or:org)
	        {
	        	if(rmuser.equalsIgnoreCase(or.getRm()))
	        	{
	        		org1.add(or);
	        		
	        	}
	        }
	       emp= session.createQuery("FROM Employee").list(); 
	       for(Employee or:emp)
	        {
	    	   for(Organisation oo:org1) {
	        	if(or.getSapId().equalsIgnoreCase(oo.getSapId()))
	        	{
	        		eee.add(or);
	        	}
	        }
	        }
	         
	      } catch (HibernateException e) {
	         if (tx!=null) tx.rollback();
	         e.printStackTrace(); 
	      } finally {
	         session.close(); 
	      }
		return  eee;
	}
	
	
}
