package service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;

import DAO.empImpl;
import model.Employee;

public class getEmpImpl implements getEmp{ 
	 @Autowired
	 // @Qualifier("petDao")
	  private empImpl e;
	   
	  


	public void setDetails( Employee emp1) {
		// TODO Auto-generated method stub
		//empImpl e=new empImpl();
		  e.addDetails(emp1);
		
		
	}



	
	   

}
