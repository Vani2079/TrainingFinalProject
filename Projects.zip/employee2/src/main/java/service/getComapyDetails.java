package service;

import java.time.LocalDate;
import java.util.Random;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.servlet.ModelAndView;

import model.Employee;
import model.Organisation;

public class getComapyDetails {
	
	static long salary1=20000;
	
	public Organisation getCompDetails(Employee e, Organisation Organisation)
	{
		Random r=new Random();
		String sapId;
		sapId=e.getSapId();
		long salary=r.nextInt(2000)+salary1;
		String username=e.getName()+"@hcl.com";
		
		String password=r.nextInt(2000)+"HCL";
		 String Rm="Pavithra";
		 Organisation.setPassword(password);
		 Organisation.setRm(Rm);
		 Organisation.setDoj("20-09-2019");
		 Organisation.setSalary(salary);
		 Organisation.setUsername(username);
		 Organisation.setSapId(sapId);
		 addDetails(Organisation, e);

		    return Organisation;
		
		
	}
	static int a=111;
	@Autowired
	private SessionFactory sessionFactory;
	
	public void addDetails(Organisation e1,Employee e) {
		
		
		
	      Session session = sessionFactory.openSession();
	      Transaction tx = null;
	     // List<Employee> emp = null;
	      
	      String  p="HCL"+a++;
	      e1.setSapId(p);
	      
	      try {
	         tx = session.beginTransaction();
	         
	         session.save(e1);
	       // session.getTransaction().commit();
	         tx.commit();
	        //Save the employee in database
	       
	        e.setSapId(e1.getSapId());
	         
		
	}catch(Exception e2)
	      {
		e2.printStackTrace();
	      }finally {
	    	  session.close();
	      }
	     

}

}
