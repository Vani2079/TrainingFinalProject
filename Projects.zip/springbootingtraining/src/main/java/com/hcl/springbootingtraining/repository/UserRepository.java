package com.hcl.springbootingtraining.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.hcl.springbootingtraining.entity.User;

@Repository
public interface UserRepository extends JpaRepository<User, Integer>{
	
	List<User> findByFirstNameAndLastName(String firstName, String lastName);
	
	List<User> findByFirstNameContainsOrderByFirstNameAsc(String firstName);
	
	//@Query("select u from User u where firstName=:firstName and lastName=:lastName")
	//List<User> getUsersByQuery(@Param("firstName") String firstName, @Param("lastName") String lastName);
	
	@Query(value="select * from user u where first_name=:firstName and last_name=:lastName", nativeQuery=true)
	List<User> getUsersByQuery(@Param("firstName") String firstName, @Param("lastName") String lastName);
	
}
