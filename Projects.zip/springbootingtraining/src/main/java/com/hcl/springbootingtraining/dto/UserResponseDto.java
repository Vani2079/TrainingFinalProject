package com.hcl.springbootingtraining.dto;

import java.util.List;

import com.hcl.springbootingtraining.entity.User;

public class UserResponseDto {
	
	private List<User> users;
	
	private String statusMessage;
	
	public List<User> getUsers() {
		return users;
	}

	public void setUsers(List<User> users) {
		this.users = users;
	}

	public String getStatusMessage() {
		return statusMessage;
	}

	public void setStatusMessage(String statusMessage) {
		this.statusMessage = statusMessage;
	}

	public int getStatusCode() {
		return statusCode;
	}

	public void setStatusCode(int statusCode) {
		this.statusCode = statusCode;
	}

	private int statusCode;

}
