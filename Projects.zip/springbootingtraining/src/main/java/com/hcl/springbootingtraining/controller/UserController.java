package com.hcl.springbootingtraining.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.hcl.springbootingtraining.dto.UserResponseDto;
import com.hcl.springbootingtraining.entity.User;
import com.hcl.springbootingtraining.service.UserService;

@RestController
@RequestMapping("/users")
public class UserController {
	
	@Autowired
	UserService userService;
	
	@PostMapping("")
	public ResponseEntity<String> saveUser(@RequestBody User user){
		String result = userService.saveUser(user);
		return new ResponseEntity<String>(result, HttpStatus.CREATED);
	}
	
	@GetMapping("")
	public UserResponseDto getAllUsers(){
		List<User> users = userService.getAllUsers();
		UserResponseDto userResponseDto = new UserResponseDto();
		userResponseDto.setUsers(users);
		userResponseDto.setStatusCode(200);
		userResponseDto.setStatusMessage("Success");
		return userResponseDto;
	}
	@GetMapping("/byNames")
	public UserResponseDto getUsersByFnameAndLname(@RequestParam String firstName, @RequestParam String lastName){
		List<User> users = userService.getUsersByFnameAndLname(firstName, lastName);
		UserResponseDto userResponseDto = new UserResponseDto();
		userResponseDto.setUsers(users);
		userResponseDto.setStatusMessage("Success");
		userResponseDto.setStatusCode(200);
		return userResponseDto;
		
	}
	
	@GetMapping("/page")
	public ResponseEntity<Page<User>> getUsersBypage(@RequestParam Integer pageNumber, @RequestParam Integer pageSize){
		return new ResponseEntity<Page<User>>(userService.getUsersBypage(pageNumber, pageSize), HttpStatus.OK);
	}

}
