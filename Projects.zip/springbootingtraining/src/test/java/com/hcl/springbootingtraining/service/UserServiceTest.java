package com.hcl.springbootingtraining.service;


import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.junit.Assert;
import org.junit.BeforeClass;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.data.domain.Sort;

import com.hcl.springbootingtraining.entity.User;
import com.hcl.springbootingtraining.repository.UserRepository;

@RunWith(MockitoJUnitRunner.Silent.class)
public class UserServiceTest {
	
	@InjectMocks
	UserService userService;
	
	@Mock
	UserRepository userRepository;
	
	static User user = new User();
	static List<User> users = new ArrayList<User>();
	
	@BeforeClass
	public static void setup(){
		user.setId(1);
		user.setFirstName("test");
		users.add(user);
	}
	
	
	
	@Test
	public void testFindByIdForPositive(){
		Mockito.when(userRepository.findById(Mockito.any())).thenReturn(Optional.of(user));
		User user = userService.findById(2);
		Assert.assertNotNull(user);
		Assert.assertEquals("test", user.getFirstName());
	}

	
	/*@Test
	public void testFindByIdForNegative(){
		Mockito.when(userRepository.findById(2)).thenReturn(Optional.of(user));
		User user = userService.findById(5);
		Assert.assertNull(user);
	}*/

	@Test(expected=NullPointerException.class)
	public void testFindByIdForExce(){
		Mockito.when(userRepository.findById(2)).thenReturn(Optional.of(user));
		userService.findById(5);
	}
	
	
	
	
	
	
	@Test
	public void testGetAllUsers(){
		Mockito.when(userRepository.findAll(Sort.by(Sort.Direction.ASC, "firstName"))).thenReturn(users);
		
		List<User> restUsers = userService.getAllUsers();
		Assert.assertNotNull(restUsers);
		Assert.assertEquals(1, restUsers.size());
	}

}
