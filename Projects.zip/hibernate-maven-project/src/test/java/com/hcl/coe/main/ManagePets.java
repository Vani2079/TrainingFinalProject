package com.hcl.coe.main;

import java.lang.annotation.Annotation;
import java.util.Iterator;
import java.util.List;

import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import com.hcl.coe.model.Pet;

public class ManagePets {

	private static SessionFactory factory;

	public static void main(String[] args) {
		try {
			
			factory = new Configuration().configure().buildSessionFactory();  
	             
		} catch (Throwable ex) {
			System.err.println("Failed to create sessionFactory object." + ex);
			throw new ExceptionInInitializerError(ex);
		}
		ManagePets mp = new ManagePets();
		/*
		 * Pet p = new Pet(); p.setPet_name("john"); p.setPet_age(6);
		 * p.setPet_place("Bg"); mp.addPet(p);
		 */
		
		mp.listPets();
		
	//	mp.updatePet(4, 25);
		
	//	mp.deletePet(8);

	}

	public int addPet(Pet p) {
		Session session = factory.openSession();
		Transaction tx = null;
		Integer petID = null;

		try {
			tx = session.beginTransaction();
			petID = (Integer) session.save(p);
			tx.commit();
		} catch (HibernateException e) {
			if (tx != null)
				tx.rollback();
			e.printStackTrace();
		} finally {
			session.close();
		}
		return petID;

	}
	
	/* Method to  READ all the employees */
	   public void listPets( ){
	      Session session = factory.openSession();
	      Transaction tx = null;
	      
	      try {
	         tx = session.beginTransaction();
	         List<Pet> pets = session.createQuery("FROM Pet").list(); 
	        // List pets = session.createSQLQuery("select * from pets").list();
	        
	         for (Iterator<Pet> iterator = pets.iterator(); iterator.hasNext();){
	            Pet pet = (Pet) iterator.next(); 
	            System.out.print("Pet Name: " + pet.getPet_name()); 
	            System.out.print(" Pet Age: " + pet.getPet_age()); 
	            System.out.println("Pet Place : " +pet.getPet_place()); 
	         }
	         tx.commit();
	      } catch (HibernateException e) {
	         if (tx!=null) tx.rollback();
	         e.printStackTrace(); 
	      } finally {
	         session.close(); 
	      }
	   }
	   
	   public void updatePet(Integer petID, int age ){
		      Session session = factory.openSession();
		      Transaction tx = null;
		      
		      try {
		         tx = session.beginTransaction();
		         Pet p = (Pet)session.get(Pet.class, petID); 
		         p.setPet_age(age);
				 session.update(p); 
		         tx.commit();
		      } catch (HibernateException e) {
		         if (tx!=null) tx.rollback();
		         e.printStackTrace(); 
		      } finally {
		         session.close(); 
		      }
		   }
		   
		   /* Method to DELETE an employee from the records */
		   public void deletePet(Integer petID){
		      Session session = factory.openSession();
		      Transaction tx = null;
		      
		      try {
		         tx = session.beginTransaction();
		         Pet pet = (Pet)session.get(Pet.class, petID); 
		         session.delete(pet); 
		         tx.commit();
		      } catch (HibernateException e) {
		         if (tx!=null) tx.rollback();
		         e.printStackTrace(); 
		      } finally {
		         session.close(); 
		      }
		   }
}
