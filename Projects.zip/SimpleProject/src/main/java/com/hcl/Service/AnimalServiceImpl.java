package com.hcl.Service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;

import com.hcl.Dao.AnimalDAO;
import com.hcl.model.Pet;

public class AnimalServiceImpl implements AnimalService {
	@Autowired
	@Qualifier("petDao")
	private AnimalDAO petDao;
	
	public List<Pet> getPets()
	{
		return petDao.getPets();
	}
	
	public int savePet(Pet p)
	{
		return petDao.savePet(p);
	}
	public Boolean savePetByPreparedStatement(final Pet p)
	{
		return petDao.savePetByPreparedStatement(p);
	}
	

}
