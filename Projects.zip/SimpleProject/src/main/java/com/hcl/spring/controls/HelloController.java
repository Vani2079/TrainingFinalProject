package com.hcl.spring.controls;

import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.hcl.Service.AnimalService;
import com.hcl.model.Pet;
import com.hcl.model.User;

@Controller
public class HelloController {
	@RequestMapping("/hello")
	// public ModelAndView display()
	// {
	// return new ModelAndView("hello","msg","Hello First Spring");
	// }
	public String display(@RequestParam("user") String name, @RequestParam("pass") String pass, Model m) {
		// public String display(HttpServletRequest req,Model m)

		// String name=req.getParameter("user");
		// String pass=req.getParameter("pass");
		if (pass.equals("admin")) {
			String msg = "Hello " + name;
			m.addAttribute("message", msg);
			return "viewpage";
		} else {
			String msg = "Sorry " + name + ".You have entered incorrect password";
			m.addAttribute("message", msg);
			return "errorpage";
		}

	}

	@RequestMapping("/bookingForm")
	public String bookingForm(Model model) {
		User u = new User();
		model.addAttribute("userDetails", u);
		return "formtaglib";

	}
	@Autowired
	AnimalService petService;

	@RequestMapping(value = "/submitForm", method = RequestMethod.POST)
	public String submitForm(@Valid @ModelAttribute("userDetails") User u,BindingResult br) {
		
		if(br.hasErrors())
		{
			return "formtaglib";
		}else {
		//System.out.println("FirstName:" + u.getFirstName());
		//System.out.println("LastName :" + u.getLastName());
		//System.out.println("Age :" + u.getAge());
		Pet pet=new Pet();
		pet.setPET_NAME("Dogieeee");
		pet.setPet_age(4);
		pet.setPet_place("blr");
		petService.savePet(pet);
		
		
		
		
		return "confirmpage";
	}
}
	
	
	
}
