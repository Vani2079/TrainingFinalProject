package com.hcl.model;

public class Pet {
	int id;
	String PET_NAME;
	int pet_age;
	String pet_place;
	String pet_owner_id;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getPET_NAME() {
		return PET_NAME;
	}
	public void setPET_NAME(String pET_NAME) {
		PET_NAME = pET_NAME;
	}
	public int getPet_age() {
		return pet_age;
	}
	public void setPet_age(int pet_age) {
		this.pet_age = pet_age;
	}
	public String getPet_place() {
		return pet_place;
	}
	public void setPet_place(String pet_place) {
		this.pet_place = pet_place;
	}
	public String getPet_owner_id() {
		return pet_owner_id;
	}
	public void setPet_owner_id(String pet_owner_id) {
		this.pet_owner_id = pet_owner_id;
	}
	
	
	

}
