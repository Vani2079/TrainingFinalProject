package com.hcl.model;

import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Size;

public class User {
	@NotBlank(message="Name cannot be empty")
	private String firstName;
	@Size(min=3,message="Minimum 3 charaters")
	private String lastName;
	@Min(value=18,message="must be equal or greater than 18")
	@Max(value=45,message="must be equal or less than 45")
	int age;

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		this.age = age;
	}

}
