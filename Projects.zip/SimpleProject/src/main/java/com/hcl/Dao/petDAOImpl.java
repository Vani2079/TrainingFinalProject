package com.hcl.Dao;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.PreparedStatementCallback;
import org.springframework.jdbc.core.RowMapper;

import com.hcl.model.Pet;

public class petDAOImpl implements AnimalDAO{
	@Autowired
	private JdbcTemplate jdbcTemplate;

	public void setJdbcTemplate(JdbcTemplate jdbcTemplate) {
		this.jdbcTemplate = jdbcTemplate;
	}

	public List<Pet> getPets() {
		String query = "select * from pets";
		PetRowMapper pRowMapper = new PetRowMapper();
		List<Pet> pets = jdbcTemplate.query(query, pRowMapper);
		return pets;
	}

	public int savePet(Pet p) {
		String query = "INSERT INTO PETS(PET_NAME, PET_AGE,PET_PLACE) VALUES('" + p.getPET_NAME() + "','"
				+ p.getPet_age() + "','" + p.getPet_place() + "')";

		return jdbcTemplate.update(query);
	}

	public Boolean savePetByPreparedStatement(final Pet p) {
		String query = "INSERT INTO PETS(PET_NAME, PET_AGE,PET_PLACE) VALUES(?,?,?)";
		return jdbcTemplate.execute(query, new PreparedStatementCallback<Boolean>() {
			@Override
			public Boolean doInPreparedStatement(PreparedStatement ps) throws SQLException, DataAccessException {
				ps.setString(1, p.getPET_NAME());
				ps.setInt(2, p.getPet_age());
				ps.setString(3, p.getPet_place());
				return ps.execute();
			}
		});
	}
}

class PetRowMapper implements RowMapper<Pet>{

	@Override
	public Pet mapRow(ResultSet rs, int rowNum) throws SQLException {
		Pet p=new Pet();  
        p.setId(rs.getInt("ID"));
        p.setPET_NAME(rs.getString("PET_NAME"));
        p.setPet_age(rs.getInt("PET_AGE"));
        p.setPet_place(rs.getString("PET_PLACE"));
        p.setPet_owner_id(rs.getString("PET_OWNER_ID"));
        return p;  
	}
	
}


