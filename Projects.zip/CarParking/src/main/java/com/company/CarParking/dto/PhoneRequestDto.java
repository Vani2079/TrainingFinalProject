package com.company.CarParking.dto;

import org.springframework.stereotype.Component;

@Component
public class PhoneRequestDto {

	private String phone;
	private String sapId;
	public String getPhone() {
		return phone;
	}
	public void setPhone(String phone) {
		this.phone = phone;
	}
	public String getSapId() {
		return sapId;
	}
	public void setSapId(String sapId) {
		this.sapId = sapId;
	}
}
