package com.company.CarParking.helper;

import org.springframework.stereotype.Component;

@Component
public class EmployeeHelper {
	static long sapId=10001;
	public  long generateSapId()
	{
		return sapId++;
	}
	
	
	

}
