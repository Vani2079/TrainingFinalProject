package com.company.CarParking.service;

import java.util.List;

import com.company.CarParking.dto.EmployeeRequestDto;

import com.company.CarParking.model.Employee;

public interface EmployeeService {

	void saveEmployee(EmployeeRequestDto employeeRequestDto);

	List<Employee> getEmployeeBySalary(double salary);

	

	

	void updatePhone(Long sapId, String phone);

}
