package com.company.CarParking.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.company.CarParking.dao.EmployeeRepository;
import com.company.CarParking.dao.OrganisationRepository;
import com.company.CarParking.dto.EmployeeRequestDto;

import com.company.CarParking.helper.EmployeeHelper;
import com.company.CarParking.model.Employee;

@Service
public class EmployeeServiceImpl implements EmployeeService{
	
	@Autowired
	EmployeeHelper employeeHelper;
	@Autowired
	EmployeeRepository employeeRepository;
	@Autowired
	OrganisationService organisationService;
	@Autowired
	OrganisationRepository organisationRepository;
	@Override
	public void saveEmployee(EmployeeRequestDto employeeRequestDto) {
		Employee employee=new Employee();
		employee.setName(employeeRequestDto.getName());
		employee.setEmail(employeeRequestDto.getEmail());
		employee.setPhoneNo(employeeRequestDto.getPhoneNo());
		employee.setAddress(employeeRequestDto.getAddress());
		employee.setDob(employeeRequestDto.getDob());
		Long sapId=employeeHelper.generateSapId();
		employee.setSapId(sapId);
		employeeRepository.save(employee);
		organisationService.generateOrganisationDetails(sapId,employeeRequestDto.getName());
		
		
	}

	@Override
	public List<Employee> getEmployeeBySalary(double salary) {
		List<Long> sapIds=organisationRepository.findBySalary(salary);
		List<Employee> employeeDetails=(List<Employee>) employeeRepository.findAllById(sapIds);
		return employeeDetails;
		
	}

	@Override
	public void updatePhone(Long sapId, String phone) {
		Optional<Employee> employee=employeeRepository.findById(sapId);
		String updatePhone="";
		if(employee.isPresent())
			updatePhone=employee.get().getPhoneNo();
			employee.get().setPhoneNo(updatePhone);
			employeeRepository.save(employee);
		
	}

	
	
		
		
	}

	


