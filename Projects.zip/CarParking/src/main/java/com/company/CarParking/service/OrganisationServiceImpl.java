package com.company.CarParking.service;

import java.time.LocalDate;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


import com.company.CarParking.dao.OrganisationRepository;
import com.company.CarParking.exception.SapIdNotFoundException;
import com.company.CarParking.helper.OrganisationHelper;
import com.company.CarParking.model.Organisation;

@Service
public class OrganisationServiceImpl implements OrganisationService {
	@Autowired
	OrganisationRepository organisationRepository;

	@Autowired
	OrganisationHelper organisationHelper;

	@Override
	public void generateOrganisationDetails(Long sapId, String name) {
		Organisation organisation = new Organisation();
		organisation.setSapId(sapId);

		String designation = organisationHelper.generateDesignation();
		organisation.setDesignation(designation);

		String mail = organisationHelper.generateMail(name);
		organisation.setCompanyEmail(mail);

		String project = organisationHelper.generateProject();
		organisation.setProject(project);

		double salary = organisationHelper.generateSalary(designation);
		organisation.setSalary(salary);
		organisation.setDoj(LocalDate.now());

		organisationRepository.save(organisation);

	}
	public Organisation getOrganisationDetails(Long sapId)
	{
		Optional<Organisation> organisation=organisationRepository.findById(sapId);
		if(!(organisation.isPresent())) 
			throw new SapIdNotFoundException("Invalid SapId  : " + sapId);
		return organisation.get();
	}

}
