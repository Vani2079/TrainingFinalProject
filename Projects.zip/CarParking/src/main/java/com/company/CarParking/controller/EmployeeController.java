package com.company.CarParking.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.company.CarParking.dto.EmployeeRequestDto;
import com.company.CarParking.model.Employee;
import com.company.CarParking.model.Organisation;
import com.company.CarParking.service.EmployeeService;
import com.company.CarParking.service.OrganisationService;



@RestController
public class EmployeeController {
	
	@Autowired
	EmployeeService employeeService;
	
	@Autowired
	OrganisationService organisationService;
	
	@PostMapping("/employees")
	public void saveCustomer(@RequestBody EmployeeRequestDto employeeRequestDto) {
		employeeService.saveEmployee(employeeRequestDto);
	}
	@GetMapping("/employees/{sapId}")
	public ResponseEntity<Organisation> read(@PathVariable("sapId") Long sapId) {

	Organisation organisation=organisationService.getOrganisationDetails(sapId);
	    
	   
	        return ResponseEntity.ok(organisation);
	    }
	@GetMapping("/salary")
	public List<Employee> getEmployeeBySalary(@RequestParam("salary") Long salary)
	{
		List<Employee> list=employeeService.getEmployeeBySalary(salary);
		
		return list;
		
	}
	@PatchMapping("/update")
	public String updatePhone(@RequestParam("phone") String phone,@RequestParam("SapId") Long sapId)
	{
		employeeService.updatePhone(sapId,phone);
		return "updated";
		
	}
}
