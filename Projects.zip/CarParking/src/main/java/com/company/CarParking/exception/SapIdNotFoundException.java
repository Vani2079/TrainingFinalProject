package com.company.CarParking.exception;

public class SapIdNotFoundException extends RuntimeException {
	private static final long serialVersionUID=1L;
	
	public  SapIdNotFoundException(String exception)
	{
		super(exception);
	}

}
