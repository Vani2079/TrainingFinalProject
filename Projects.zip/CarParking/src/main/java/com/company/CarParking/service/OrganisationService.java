package com.company.CarParking.service;



import com.company.CarParking.model.Organisation;

public interface OrganisationService {
	public void generateOrganisationDetails(Long sapId,String name);
	public Organisation getOrganisationDetails(Long sapId);
	

}
