package com.company.CarParking.helper;

import java.util.Arrays;
import java.util.List;
import java.util.Random;

import org.springframework.stereotype.Component;

@Component
public class OrganisationHelper {
	public String generateDesignation() {
		List<String> designation = Arrays.asList("UI developer", "It support", "Manager", "java developer");
		Random rand = new Random();
		String random = designation.get(rand.nextInt(designation.size()));
		return random;
	}

	public String generateMail(String name) {

		return name + "@hcl.com";
	}

	public String generateProject() {
		List<String> project = Arrays.asList("City", "ING", "DB", "HDFC");
		Random rand = new Random();
		String random = project.get(rand.nextInt(project.size()));
		return random;
	}

	public double generateSalary(String designation) {
		if (designation.equalsIgnoreCase("UI developer"))
			return 30000;
		else if (designation.equalsIgnoreCase("It support"))
			return 20000;
		else if (designation.equalsIgnoreCase("Manager"))
			return 60000;
		else
			return 50000;

	}

}
