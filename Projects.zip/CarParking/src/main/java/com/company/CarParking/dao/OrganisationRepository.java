package com.company.CarParking.dao;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.company.CarParking.model.Organisation;

@Repository
public interface OrganisationRepository extends CrudRepository<Organisation,Long>{

	@Query("select sapId from Organisation where salary>=?1")
	List<Long> findBySalary(double salary);

}
