package com.company.CarParking.service;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;


import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;

import com.company.CarParking.dao.EmployeeRepository;
import com.company.CarParking.dao.OrganisationRepository;
import com.company.CarParking.model.Employee;

public class EmployeeServiceTest {

	@InjectMocks
	EmployeeService employeeService;

	@Mock
	EmployeeRepository employeeRepository;
	
	@Mock
	OrganisationRepository organisationRepository;

	static Employee employee = new Employee();
	static List<Long> users = new ArrayList<Long>();
	static List<Employee> employeeList = new ArrayList<Employee>();

	/*
	 * @Before public static void setup() { employee.setName("vani");
	 * employee.setAddress("jayanagar");
	 * employee.setDob(LocalDate.parse("2019-09-09"));
	 * employee.setEmail("vani@gmail.com"); employee.setPassword("vani");
	 * employee.setPhoneNo("756775");
	 * 
	 * }
	 */

	@Test
	public void testFindByIdForPositive() {
		Mockito.when(organisationRepository.findBySalary(Mockito.any())).thenReturn(users);
		Mockito.when(employeeRepository.findAllById(users)).thenReturn(employeeList);
		
		//Assert.assertNotNull(users);
		Assert.assertEquals("test", users);
	}

	/*
	 * @Test public void testFindByIdForNegative(){
	 * Mockito.when(userRepository.findById(2)).thenReturn(Optional.of(user)); User
	 * user = userService.findById(5); Assert.assertNull(user); }
	 */

	
}
