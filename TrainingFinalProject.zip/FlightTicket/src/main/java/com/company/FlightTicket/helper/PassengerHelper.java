package com.company.FlightTicket.helper;

import org.springframework.stereotype.Component;

import com.company.FlightTicket.model.Passanger;
import com.company.FlightTicket.model.PassengerCompositeKey;

@Component
public class PassengerHelper {

	static Long id = 10001L;

	public PassengerCompositeKey generatePassengerId(Passanger passanger, PassengerCompositeKey key) {

		key.setPassengerId(id++);

		passanger.setPassengerCompsiteKey(key);
		return key;

	}

}
