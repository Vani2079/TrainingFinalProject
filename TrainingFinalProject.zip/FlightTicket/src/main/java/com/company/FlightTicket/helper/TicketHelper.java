package com.company.FlightTicket.helper;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.stereotype.Component;

import com.company.FlightTicket.dto.TicketStatusResponseDto;
import com.company.FlightTicket.model.Category;
import com.company.FlightTicket.model.Flight;
import com.company.FlightTicket.model.Ticket;



@Component
public class TicketHelper {
	@Autowired
	private JavaMailSender javaMailSender;


	public TicketStatusResponseDto getflightDetails(Flight flight,TicketStatusResponseDto ticketStatusResponseDto) {
		
		ticketStatusResponseDto.setSource(flight.getSource());
		ticketStatusResponseDto.setDestination(flight.getDestination());
		
		return ticketStatusResponseDto;
	}
	
	public TicketStatusResponseDto getCostDetails(Category category, Optional<Ticket> ticket,TicketStatusResponseDto ticketStatusResponseDto) {
		if (ticket.get().getCategory().equalsIgnoreCase("Business"))
			ticketStatusResponseDto.setTotalCost(category.getBusinessSeatCost() * ticket.get().getNoOfSeats());
		else
			ticketStatusResponseDto.setTotalCost(category.getEconomicSeatCost() * ticket.get().getNoOfSeats());
		return ticketStatusResponseDto;
		
		
	}
	
	
	public void sendEmail( Ticket ticket) {

        SimpleMailMessage msg = new SimpleMailMessage();
        msg.setTo("flightTicketBooking123@gmail.com");

        msg.setSubject("Your ticket has been confirmed!.");
        
        msg.setText("Your ticket Id is: "+ticket.getTicketId()+"\t"+" Airport Id : "+ticket.getAirportId()
        +"   Your flight Id is:  "+ticket.getFlightId());
        

        javaMailSender.send(msg);


}
}
