package com.company.FlightTicket.service;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.company.FlightTicket.dao.PassengerRepository;
import com.company.FlightTicket.dto.PassengerRequestDto;
import com.company.FlightTicket.dto.TicketRequestDto;
import com.company.FlightTicket.helper.PassengerHelper;
import com.company.FlightTicket.model.Passanger;
import com.company.FlightTicket.model.PassengerCompositeKey;

@Service
public class PassengerServiceImpl implements PassengerService {

	@Autowired
	PassengerRepository passengerRepository;
	@Autowired
	ModelMapper modelMapper;
	@Autowired
	PassengerHelper passengerHelper;

	@Override
	public void savepassenger(TicketRequestDto ticketRequestDto) {
		for (PassengerRequestDto passengerRequestDto : ticketRequestDto.getPassengers()) {
			Passanger passanger = modelMapper.map(passengerRequestDto, Passanger.class);
			PassengerCompositeKey key = new PassengerCompositeKey();
			key = passengerHelper.generatePassengerId(passanger, key);
			key.setUserId(ticketRequestDto.getUserId());

			passengerRepository.save(passanger);

		}
	}
}
