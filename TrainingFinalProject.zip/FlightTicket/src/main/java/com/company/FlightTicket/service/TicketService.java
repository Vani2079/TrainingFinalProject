package com.company.FlightTicket.service;

import com.company.FlightTicket.dto.TicketRequestDto;

import com.company.FlightTicket.dto.TicketStatusResponseDto;

public interface TicketService {

	public Long bookTicket(TicketRequestDto ticketRequestDto);

	public TicketStatusResponseDto getTicketStatus(Long ticketId);

	

}
