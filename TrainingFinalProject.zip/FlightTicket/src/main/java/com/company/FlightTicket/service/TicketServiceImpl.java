package com.company.FlightTicket.service;

import java.util.Optional;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.company.FlightTicket.dao.TicketRepository;
import com.company.FlightTicket.dto.TicketRequestDto;
import com.company.FlightTicket.dto.TicketStatusResponseDto;
import com.company.FlightTicket.exception.PassengerCountException;
import com.company.FlightTicket.exception.TicketNotFoundException;
import com.company.FlightTicket.helper.TicketHelper;
import com.company.FlightTicket.model.Airport;
import com.company.FlightTicket.model.Category;
import com.company.FlightTicket.model.Flight;
import com.company.FlightTicket.model.Ticket;
import com.company.FlightTicket.model.User;

@Service
public class TicketServiceImpl implements TicketService {

	@Autowired
	ModelMapper modelMapper;
	@Autowired
	TicketRepository ticketRepository;
	@Autowired
	PassengerService passengerService;
	@Autowired
	RestTemplate restTemplate;
	@Autowired
	TicketHelper ticketHelper;

	@Override
	public Long bookTicket(TicketRequestDto ticketRequestDto) {
		if (ticketRequestDto.getPassengers().size() > 3
				|| ticketRequestDto.getSeats() != ticketRequestDto.getPassengers().size()) {
			throw new PassengerCountException("passenger count mismatch");
		}
		restTemplate.getForObject("http://USERS/flight/users/" + ticketRequestDto.getUserId(), User.class);
		restTemplate.getForObject("http://SEARCH/search/flights/" + ticketRequestDto.getFlightId(), Flight.class);
		restTemplate.getForObject("http://SEARCH/search/airport/" + ticketRequestDto.getAirportId(), Airport.class);
		if (ticketRequestDto.getCategory().equalsIgnoreCase("business"))
			restTemplate.getForObject("http://SEARCH/search/BusinessSeats?filghtId=" + ticketRequestDto.getFlightId()
					+ "&seats=" + ticketRequestDto.getSeats(), Category.class);
		else
			restTemplate.getForObject("http://SEARCH/search/EconomicSeats?filghtId=" + ticketRequestDto.getFlightId()
					+ "&seats=" + ticketRequestDto.getSeats(), Category.class);
		Ticket ticket = modelMapper.map(ticketRequestDto, Ticket.class);

		ticket.setNoOfSeats(ticketRequestDto.getSeats());
		ticketRepository.save(ticket);

		passengerService.savepassenger(ticketRequestDto);
		restTemplate.postForObject(
				"http://SEARCH/search/updateSeats?flightId=" + ticketRequestDto.getFlightId() + "&categoryType="
						+ ticketRequestDto.getCategory() + "&seats=" + ticketRequestDto.getSeats(),
				null, Category.class);
		ticketHelper.sendEmail(ticket);
		return ticket.getTicketId();

	}

	@Override
	public TicketStatusResponseDto getTicketStatus(Long ticketId) {

		Optional<Ticket> ticket = ticketRepository.findById(ticketId);
		if (!ticket.isPresent()) {
			throw new TicketNotFoundException("No ticket found with this Id,Enter valid ticketId");
		}

		TicketStatusResponseDto ticketStatusResponseDto = modelMapper.map(ticket.get(), TicketStatusResponseDto.class);

		String flightId = ticketStatusResponseDto.getFlightId();

		Flight flight = restTemplate.getForObject("http://SEARCH/search/flights/" + flightId, Flight.class);
		ticketStatusResponseDto = ticketHelper.getflightDetails(flight, ticketStatusResponseDto);

		Category category = restTemplate.getForObject("http://SEARCH/search/category/" + flightId, Category.class);
		ticketStatusResponseDto = ticketHelper.getCostDetails(category, ticket, ticketStatusResponseDto);

		return ticketStatusResponseDto;
	}

}
