package com.company.FlightTicket.exception;

public class PassengerCountException extends RuntimeException {
	private static final long serialVersionUID = 1L;

	public PassengerCountException(String exception) {
		super(exception);
	}
}
