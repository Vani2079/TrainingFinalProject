package com.company.FlightTicket.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.company.FlightTicket.dto.TicketRequestDto;

import com.company.FlightTicket.dto.TicketStatusResponseDto;
import com.company.FlightTicket.service.TicketService;

@RestController
public class TicketController {
	private final Logger logger = LoggerFactory.getLogger(TicketController.class);
	@Autowired
	TicketService ticketService;
	
	/*
	 * To book the ticket
	 * 
	 * @param-TicketRequestDto
	 * 
	 * @return-Ticket Id
	 */
	@PostMapping("/tickets")
	public ResponseEntity<Long> bookTicket(@RequestBody TicketRequestDto ticketRequestDto) {
		Long ticketId = ticketService.bookTicket(ticketRequestDto);
		logger.info("saving the ticket");
		return new ResponseEntity<>(ticketId, HttpStatus.OK);

	}
	/*
	 * To check the ticket status
	 * 
	 * @param-ticketId
	 * 
	 * @return-TicketStatusResponseDto
	 */
	@GetMapping("/tickets")
	public ResponseEntity<TicketStatusResponseDto> getTicketStatus(@RequestParam Long ticketId) {
		logger.info("Ticket Status check");
		TicketStatusResponseDto ticketStatusResponseDto=ticketService.getTicketStatus(ticketId);
		return new ResponseEntity<>(ticketStatusResponseDto, HttpStatus.OK);

	}
	

}
