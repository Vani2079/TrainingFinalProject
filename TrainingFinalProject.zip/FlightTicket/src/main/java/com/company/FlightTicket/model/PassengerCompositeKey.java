package com.company.FlightTicket.model;

import java.io.Serializable;
import org.springframework.stereotype.Component;

@Component
public class PassengerCompositeKey implements Serializable {

	private static final long serialVersionUID = 1L;
	
	
	private Long passengerId;
	public Long getPassengerId() {
		return passengerId;
	}
	public void setPassengerId(Long passengerId) {
		this.passengerId = passengerId;
	}
	public Long getUserId() {
		return userId;
	}
	public void setUserId(Long userId) {
		this.userId = userId;
	}
	private Long userId;
	

}
