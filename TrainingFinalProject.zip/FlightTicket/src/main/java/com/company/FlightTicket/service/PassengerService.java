package com.company.FlightTicket.service;

import com.company.FlightTicket.dto.TicketRequestDto;

public interface PassengerService {

	void savepassenger(TicketRequestDto ticketRequestDto);

}
