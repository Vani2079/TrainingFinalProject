package com.company.FlightTicket.exceptionHandler;

import java.time.LocalDateTime;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;

import com.company.FlightTicket.exception.TicketNotFoundException;

@ControllerAdvice
public class TicketExceptionController extends ResponseEntityExceptionHandler {
	@ExceptionHandler(TicketNotFoundException.class)
	public ResponseEntity<Error> handleEception(TicketNotFoundException exception) {
		Error error = new Error();
		error.setMessage(exception.getMessage());
		error.setStatus(HttpStatus.NOT_FOUND.value());
		error.setTimestamp(LocalDateTime.now());
		error.setSuggestion("Enter valid Ticket Id!");
		return new ResponseEntity<Error>(error, HttpStatus.NOT_FOUND);
	}

}
