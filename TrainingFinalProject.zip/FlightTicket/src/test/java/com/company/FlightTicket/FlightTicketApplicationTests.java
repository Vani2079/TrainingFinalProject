package com.company.FlightTicket;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FlightTicketApplicationTests {

	@Test
	void contextLoads() {
	}

}
