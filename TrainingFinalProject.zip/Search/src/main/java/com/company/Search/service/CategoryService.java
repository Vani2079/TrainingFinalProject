package com.company.Search.service;

import java.util.List;

import com.company.Search.model.Category;

public interface CategoryService {

	List<Category> getCategoryDetails();

	void getAvailableEconomicSeats(String filghtId, int seats);

	void getAvailableBusinessSeats(String filghtId, int seats);
	Category  findById(String filghtId);
	
	void updateSeats(String flightId,String category,int seats);
}
