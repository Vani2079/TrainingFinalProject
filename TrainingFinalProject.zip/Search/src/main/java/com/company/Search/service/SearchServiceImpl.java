package com.company.Search.service;

import java.sql.Date;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.company.Search.ResponseDto.SearchResponseDto;
import com.company.Search.dao.FlightRepository;
import com.company.Search.exception.NoFlightIdFoundExecption;
import com.company.Search.exception.ResourceNotFoundException;

import com.company.Search.helper.FlightHelper;
import com.company.Search.model.Category;
import com.company.Search.model.Flight;

@Service
public class SearchServiceImpl implements SearchService {
	@Autowired
	FlightRepository flightRepository;
	@Autowired
	FlightHelper flightHelper;
	@Autowired
	ModelMapper modelMapper;
	@Autowired
	CategoryService categoryService;

	List<Flight> flightList = new ArrayList<Flight>();
	List<Category> categoryDetailsList = new ArrayList<Category>();
	List<SearchResponseDto> searchResponseDtoList = new ArrayList<SearchResponseDto>();

	/*
	 * To search for the given input from the user by source,destination and by date
	 */
	@Override
	public List<SearchResponseDto> getDetails(String source, String destination, Date date) {
		searchResponseDtoList.clear();
		// List flightList1 =
		// flightRepository.stream().map(x->x*x).collect(Collectors.toList());
		flightList = flightRepository.findBySourceAndDestinationAndDate(source, destination, date);
		if (flightList.isEmpty())
			throw new ResourceNotFoundException("No search results found!Please check with other dates");

		searchResponseDtoList = flightList.stream().map(flight -> setSearchResponseDto(flight))
				.collect(Collectors.toList());

		return searchResponseDtoList;
	}

	/*
	 * To apply filters based on search results, to filter by flightName
	 */
	@Override
	public List<SearchResponseDto> getDetailsByflightName(String source, String destination, Date date, String name) {
		/*
		 * if (searchResponseDtoList.isEmpty()) throw new
		 * ResourceNotFoundException("Please search and then apply filters!");
		 */
		getDetails( source,destination, date);
		List<SearchResponseDto> results = searchResponseDtoList.stream()
				.filter(x -> name.equalsIgnoreCase(x.getFlightName())).collect(Collectors.toList());
		if (results.isEmpty())
			throw new ResourceNotFoundException("No results found! on date: " + date + " from source: " + source
					+ " to destination: " + destination);

		return (List<SearchResponseDto>) results;

	}

	/*
	 * To apply filters based on search results,to filter by cost given by the user
	 */
	@Override
	public List<SearchResponseDto> getDetailsByCost(String source, String destination, Date date, double cost) {
		/*
		 * if (searchResponseDtoList.isEmpty()) throw new
		 * ResourceNotFoundException("Please search and then apply filters!");
		 */
		getDetails( source,destination, date);
		List<SearchResponseDto> results = searchResponseDtoList.stream()
				.filter(x -> cost <= x.getCostPerSeatBusiness() || cost <= x.getCostPerSeatEconomic())
				.collect(Collectors.toList());
		if (results.isEmpty())
			throw new ResourceNotFoundException(
					"No results found!  " + " from source: " + source + " to destination: " + destination);

		return (List<SearchResponseDto>) results;

	}

	@Override
	public Flight getFlightDetails(String filghtId) {
		Optional<Flight> flight = flightRepository.findById(filghtId);
		if (!flight.isPresent())
			throw new NoFlightIdFoundExecption("Flight Id not found please enter correct flight Id");
		return flight.get();
	}

	public SearchResponseDto setSearchResponseDto(Flight flight) {

		SearchResponseDto searchResponseDto = modelMapper.map(flight, SearchResponseDto.class);
		String durationTime = flightHelper.calculateDurationTime(flight);

		searchResponseDto.setDurationTime(durationTime);

		Category category = categoryService.findById(flight.getFlightId());
		searchResponseDto.setCostPerSeatEconomic(category.getEconomicSeatCost());
		searchResponseDto.setCostPerSeatBusiness(category.getBusinessSeatCost());
		searchResponseDto.setAvailableSeatsEconomic(category.getEconomicSeat());
		searchResponseDto.setAvailableSeatsBusiness(category.getNoOfBusinessSeats());

		return searchResponseDto;
	}
}
