package com.company.Search.controller;

import java.sql.Date;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestParam;

import org.springframework.web.bind.annotation.RestController;

import com.company.Search.ResponseDto.SearchResponseDto;
import com.company.Search.model.Flight;

import com.company.Search.service.SearchService;

@RestController
public class searchController {
	@Autowired
	SearchService searchService;

	private final Logger logger = LoggerFactory.getLogger(searchController.class);

	/*
	 * Search by the given inputs from the user
	 * 
	 * @Param-source,destination,date
	 * 
	 * @Return-List of flightResponseDto
	 */

	@GetMapping("/flights")
	public ResponseEntity<List<SearchResponseDto>> getflights(@RequestParam String source,
			@RequestParam String destination, @RequestParam Date date) {

		logger.info("Search Query");
		List<SearchResponseDto> SearchList = searchService.getDetails(source, destination, date);
		return new ResponseEntity<>(SearchList, HttpStatus.OK);

	}

	/*
	 * Search by the given inputs from the user by applying filters
	 * 
	 * @Param-source,destination,date,Name
	 * 
	 * @Return-List of flightResponseDto
	 */
	@GetMapping("/flights/filterByName")
	public ResponseEntity<List<SearchResponseDto>> getflightsByName(@RequestParam String source,
			@RequestParam String destination, @RequestParam Date date, @RequestParam String name) {
		logger.info("Search By flightName");
		List<SearchResponseDto> SearchList = searchService.getDetailsByflightName(source, destination, date, name);

		return new ResponseEntity<>(SearchList, HttpStatus.OK);
	}

	/*
	 * Search by the given inputs from the user by applying filters
	 * 
	 * @Param-source,destination,date,cost
	 * 
	 * @Return-List of flightResponseDto
	 */
	@GetMapping("/flights/filterByCost")
	public ResponseEntity<List<SearchResponseDto>> getflightsByCost(@RequestParam String source,
			@RequestParam String destination, @RequestParam Date date, @RequestParam double cost) {
		logger.info("Search By flightName");
		List<SearchResponseDto> SearchList = searchService.getDetailsByCost(source, destination, date, cost);
		return new ResponseEntity<>(SearchList, HttpStatus.OK);
	}

	/*
	 * To get the flight details
	 * 
	 * @Param-flightId
	 * 
	 * @Return-Flight Details
	 */
	@GetMapping("/flights/{flightId}")
	public ResponseEntity<Flight> getFlightDetails(@PathVariable("flightId") String filghtId) {

		Flight flight = searchService.getFlightDetails(filghtId);
		return new ResponseEntity<>(flight, HttpStatus.OK);
	}

}
