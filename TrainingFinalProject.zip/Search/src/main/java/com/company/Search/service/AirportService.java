package com.company.Search.service;

import com.company.Search.model.Airport;


public interface AirportService {

	Airport checkAirportId(String airportId);

}
