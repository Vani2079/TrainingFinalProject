package com.company.Search.helper;

import org.springframework.stereotype.Component;

import com.company.Search.model.Flight;

@Component
public class FlightHelper {
	public String calculateDurationTime(Flight flight) {
		
		/*
		 * To calcualate the duration time 
		 */
		@SuppressWarnings("deprecation")
		String duration = (flight.getArrivalTime().getHours() - flight.getDepartureTime().getHours()) + " Hours"
				+ (flight.getArrivalTime().getMinutes() - flight.getDepartureTime().getMinutes()) + " Minutes";
		return duration;

	}

}
