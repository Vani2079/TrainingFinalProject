package com.company.Search.service;

import java.sql.Date;

import java.util.List;

import com.company.Search.ResponseDto.SearchResponseDto;
import com.company.Search.model.Flight;

public interface SearchService {

	List<SearchResponseDto> getDetails(String source, String destination, Date date);

	List<SearchResponseDto> getDetailsByflightName(String source, String destination, Date date, String name);

	List<SearchResponseDto> getDetailsByCost(String source, String destination, Date date, double cost);

	Flight getFlightDetails(String filghtId);
	
	
	

}
