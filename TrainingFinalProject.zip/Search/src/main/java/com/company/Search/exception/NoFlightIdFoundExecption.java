package com.company.Search.exception;

public class NoFlightIdFoundExecption extends RuntimeException {

	private static final long serialVersionUID = 1L;

	public NoFlightIdFoundExecption(String exception) {
		super(exception);
	}

}
