package com.company.Search.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.company.Search.dao.CategoryRepository;
import com.company.Search.exception.ResourceNotFoundException;
import com.company.Search.model.Category;

@Service
public class CategoryServiceImpl implements CategoryService {

	@Autowired
	CategoryRepository categoryRepository;

	/*
	 * To get all the details from category repository
	 */
	@Override
	public List<Category> getCategoryDetails() {
		List<Category> categoryList = (List<Category>) categoryRepository.findAll();

		return categoryList;
	}

	/*
	 * To get the details of flight by using flightId and fetch number of economic
	 * seats
	 */
	@Override
	public void getAvailableEconomicSeats(String filghtId, int seats) {
		Category category = findById(filghtId);
		if (category.getEconomicSeat() < seats)
			throw new ResourceNotFoundException("insufficient seats");

	}

	/*
	 * To get the details of flight by using flightId and fetch number of business
	 * seats
	 */
	@Override
	public void getAvailableBusinessSeats(String filghtId, int seats) {
		Category category = findById(filghtId);

		if (category.getNoOfBusinessSeats() < seats)
			throw new ResourceNotFoundException("insufficient seats");

	}

	@Override
	public Category findById(String filghtId) {
		Optional<Category> category = categoryRepository.findById(filghtId);
		return category.get();
	}

	@Override
	public void updateSeats(String flightId, String CategoryType, int seats) {
		Category category = findById(flightId);
		if (CategoryType.equalsIgnoreCase("business")) {
			category.setNoOfBusinessSeats(category.getNoOfBusinessSeats() - seats);
		} else
			category.setEconomicSeat(category.getEconomicSeat() - seats);

		categoryRepository.save(category);

	}

}
