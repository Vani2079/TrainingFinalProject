package com.company.Search.dao;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.company.Search.model.Category;

@Repository
public interface CategoryRepository extends CrudRepository<Category,String> {

}
