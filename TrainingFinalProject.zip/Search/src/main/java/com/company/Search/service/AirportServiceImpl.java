package com.company.Search.service;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.company.Search.dao.AirportRepository;
import com.company.Search.exception.AirportIdNotFoundException;
import com.company.Search.model.Airport;

@Service
public class AirportServiceImpl implements AirportService {

	@Autowired
	AirportRepository airportRepository;

	@Override
	public Airport checkAirportId(String airportId) {
		Optional<Airport> airport = airportRepository.findById(airportId);
		if (!(airport.isPresent()))
			throw new AirportIdNotFoundException("Airport id not found");

		return airport.get();

	}

}
