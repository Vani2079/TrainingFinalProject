package com.company.Search.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.company.Search.model.Category;
import com.company.Search.service.CategoryService;

@RestController
public class CategoryController {
	@Autowired
	CategoryService categoryService;
	private final Logger logger = LoggerFactory.getLogger(CategoryController.class);

	/*
	 * To search available economic seats
	 * 
	 * @Param-flightId
	 * 
	 * @Return-Number of available economic seats
	 */
	@GetMapping("/EconomicSeats")
	public ResponseEntity<String> getAvailableEconomicSeats(@RequestParam String filghtId, @RequestParam int seats) {
		logger.info("check availability");
		categoryService.getAvailableEconomicSeats(filghtId, seats);
		return new ResponseEntity<>(null, HttpStatus.OK);

	}

	/*
	 * To search available Business seats
	 * 
	 * @Param-flightId
	 * 
	 * @Return-Number of available Business seats
	 */
	@GetMapping("/BusinessSeats")
	public ResponseEntity<String> getAvailableBusinessSeats(@RequestParam String filghtId, @RequestParam int seats) {

		categoryService.getAvailableBusinessSeats(filghtId, seats);
		return new ResponseEntity<>(null, HttpStatus.OK);
	}

	/*
	 * To get the category details
	 * 
	 * @Param-flightId
	 * 
	 * @Return-flight details
	 */
	@GetMapping("/category/{flightId}")
	public ResponseEntity<Category> getCategoryDetails(@PathVariable String flightId) {
		logger.info("get the category details");
		Category category = categoryService.findById(flightId);
		return new ResponseEntity<>(category, HttpStatus.OK);
	}

	/*
	 * update the seats after ticket is booked
	 * 
	 * @Param-flightId,category,noOfSeats
	 * 
	 * @Return-null
	 */
	@PostMapping("/updateSeats")
	public ResponseEntity<String> updateSeats(@RequestParam String flightId, @RequestParam String categoryType,
			@RequestParam int seats) {
		logger.info("Update seats");
		categoryService.updateSeats(flightId, categoryType, seats);
		return new ResponseEntity<>(null, HttpStatus.OK);
	}
}
