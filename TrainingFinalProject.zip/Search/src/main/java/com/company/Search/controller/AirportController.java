package com.company.Search.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import com.company.Search.service.AirportService;

@RestController
public class AirportController {

	@Autowired
	AirportService airportService;
	private final Logger logger = LoggerFactory.getLogger(AirportController.class);

	/*
	 * To check the airportId
	 * 
	 * @Param-airportId
	 * 
	 * @Return-null
	 */
	@GetMapping("/airport/{airportId}")
	public ResponseEntity<String> checkAirportId(@PathVariable("airportId") String airportId) {
		logger.info("Searching for airport Id");
		airportService.checkAirportId(airportId);
		return new ResponseEntity<>(null, HttpStatus.OK);
	}
}
