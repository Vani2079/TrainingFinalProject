package com.company.Search.exception;

public class AirportIdNotFoundException extends RuntimeException {

	private static final long serialVersionUID = 1L;

	public AirportIdNotFoundException(String exception) {
		super(exception);
	}

}
