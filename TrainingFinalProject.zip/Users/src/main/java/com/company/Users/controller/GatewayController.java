package com.company.Users.controller;

import java.sql.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import com.company.Users.dto.SearchResponseDto;
import com.company.Users.dto.TicketRequestDto;
import com.company.Users.dto.TicketStatusResponseDto;

@RestController
public class GatewayController {
	@Autowired
	RestTemplate restTemplete;

	/*
	 * search for flight details
	 * 
	 * @param-source,destination,date
	 * 
	 * @return-List of the flights
	 */
	@GetMapping("/flights")
	public ResponseEntity<List<SearchResponseDto>> getflights(@RequestParam String source,
			@RequestParam String destination, @RequestParam Date date) {
		@SuppressWarnings("unchecked")
		List<SearchResponseDto> responseDtoList = restTemplete.getForEntity(
				"http://SEARCH/search/flights?source=" + source + "&destination=" + destination + "&date=" + date,
				List.class).getBody();

		return new ResponseEntity<>(responseDtoList, HttpStatus.OK);
	}

	/*
	 * fliter the flight details based on cost
	 * 
	 * @param-source,destination,date,cost
	 * 
	 * @return-List of the flights
	 */
	@GetMapping("/flights/filterByCost")
	public ResponseEntity<List<SearchResponseDto>> getflightsByCost(@RequestParam String source,
			@RequestParam String destination, @RequestParam Date date, @RequestParam double cost) {

		@SuppressWarnings("unchecked")
		List<SearchResponseDto> SearchList = restTemplete
				.getForEntity("http://SEARCH/search/flights/filterByCost?source=" + source + "&destination="
						+ destination + "&date=" + date + "&cost=" + cost, List.class)
				.getBody();
		return new ResponseEntity<>(SearchList, HttpStatus.OK);
	}

	/*
	 * fliter the flight details based on flightName
	 * 
	 * @param-source,destination,date,flightName
	 * 
	 * @return-List of the flights
	 */
	@GetMapping("/flights/filterByName")
	public ResponseEntity<List<SearchResponseDto>> getflightsByName(@RequestParam String source,
			@RequestParam String destination, @RequestParam Date date, @RequestParam String name) {

		@SuppressWarnings("unchecked")
		List<SearchResponseDto> SearchList = restTemplete
				.getForEntity("http://SEARCH/search/flights/filterByName?source=" + source + "&destination="
						+ destination + "&date=" + date + "&name=" + name, List.class)
				.getBody();
		return new ResponseEntity<>(SearchList, HttpStatus.OK);
	}

	/*
	 * To book the ticket
	 * 
	 * @param-TicketRequestDto
	 * 
	 * @return-Ticket Id
	 */
	@PostMapping("/tickets")
	public ResponseEntity<Long> bookTicket(@RequestBody TicketRequestDto ticketRequestDto) {

		ResponseEntity<Long> ticketId = restTemplete.postForEntity("http://FLIGHTTICKET/Ticket/tickets",
				ticketRequestDto, Long.class);
		return ticketId;

	}

	/*
	 * To check the ticket status
	 * 
	 * @param-ticketId
	 * 
	 * @return-TicketStatusResponseDto
	 */
	@GetMapping("/tickets")
	public ResponseEntity<TicketStatusResponseDto> getTicketStatus(@RequestParam Long ticketId) {
		TicketStatusResponseDto ticketStatusResponseDto = restTemplete
				.getForEntity("http://FLIGHTTICKET/Ticket/tickets?ticketId=" + ticketId, TicketStatusResponseDto.class)
				.getBody();

		return new ResponseEntity<>(ticketStatusResponseDto, HttpStatus.OK);

	}

}
