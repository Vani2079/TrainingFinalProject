package com.company.Users.service;

import java.util.Optional;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.company.Users.Exception.UserNotFoundException;
import com.company.Users.dao.UserRepository;
import com.company.Users.dto.UserRequestDto;
import com.company.Users.helper.UserHelper;
import com.company.Users.model.User;

@Service
public class UserServiceImpl implements UserService {

	@Autowired
	UserRepository userRepository;

	@Autowired
	ModelMapper modelMapper;
	@Autowired
	UserHelper userHelper;

	/* To save the users details in the database */
	@Override
	public void saveUserDetails(UserRequestDto userRequestDto) {
		User user = modelMapper.map(userRequestDto, User.class);

		String password = userHelper.encryptPassword(userRequestDto.getPassword());
		user.setPassword(password);

		userRepository.save(user);

	}

	/* Login validation */
	@Override
	public void validateUser(String email, String password) {
		String encryptedPassword = userHelper.encryptPassword(password);

		User user = userRepository.findByEmailAndPassword(email, encryptedPassword);
		if (user == null)/* Exception Handling */
			throw new UserNotFoundException("No user found!Please Register");

	}

	/* To check if the user is valid,while booking ticket */
	@Override
	public void checkUserId(Long userId) {
		Optional<User> user = userRepository.findById(userId);
		if (!(user.isPresent()))
			throw new UserNotFoundException("User not found");

	}

}
