package com.company.Users.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.company.Users.dto.UserRequestDto;
import com.company.Users.model.User;
import com.company.Users.service.UserService;

@RestController
public class UserController {
	private final Logger logger = LoggerFactory.getLogger(UserController.class);
	@Autowired
	UserService userService;

	/*
	 * To save the user details * @param-email,password
	 * 
	 * @return-Ticket Id
	 */
	@PostMapping("/users")
	public ResponseEntity<String> saveUsers(@RequestBody UserRequestDto userRequestDto) {
		userService.saveUserDetails(userRequestDto);
		logger.info("saved");

		return new ResponseEntity<>("Registered Successfully", HttpStatus.CREATED);

	}
	/*
	 * To validate the user
	 * 
	 * @param-email,password
	 * 
	 * @return-Ticket Id
	 */

	@GetMapping("/users")
	public ResponseEntity<String> validateUser(@RequestParam String email, @RequestParam String password) {
		userService.validateUser(email, password);
		logger.info("validate user");
		return new ResponseEntity<>("Welcome! Logged in Successfully", HttpStatus.OK);

	}

	/*
	 * verify the user Id while booking the ticket
	 * 
	 * @param-userId
	 * 
	 * @return-null
	 */
	/* verify the user Id while booking the ticket */
	@GetMapping("/users/{userId}")
	public ResponseEntity<User> checkUserId(@PathVariable Long userId) {
		logger.info("check for valid user Id");
		userService.checkUserId(userId);
		return new ResponseEntity<>(HttpStatus.OK);
	}

}
