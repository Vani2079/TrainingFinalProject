package com.company.Users.dto;

import java.sql.Time;

import org.springframework.stereotype.Component;

@Component
public class SearchResponseDto {
	private String flightId;
	private String flightName;
	private Time departureTime;
	private Time arrivalTime;
	private String durationTime;
	private int availableSeatsBusiness;
	private int availableSeatsEconomic;

	public int getAvailableSeatsBusiness() {
		return availableSeatsBusiness;
	}

	public void setAvailableSeatsBusiness(int availableSeatsBusiness) {
		this.availableSeatsBusiness = availableSeatsBusiness;
	}

	public int getAvailableSeatsEconomic() {
		return availableSeatsEconomic;
	}

	public void setAvailableSeatsEconomic(int availableSeatsEconomic) {
		this.availableSeatsEconomic = availableSeatsEconomic;
	}

	private double costPerSeatEconomic;
	private double costPerSeatBusiness;

	public String getFlightId() {
		return flightId;
	}

	public void setFlightId(String flightId) {
		this.flightId = flightId;
	}

	public String getFlightName() {
		return flightName;
	}

	public void setFlightName(String flightName) {
		this.flightName = flightName;
	}

	public Time getDepartureTime() {
		return departureTime;
	}

	public void setDepartureTime(Time departureTime) {
		this.departureTime = departureTime;
	}

	public Time getArrivalTime() {
		return arrivalTime;
	}

	public void setArrivalTime(Time arrivalTime) {
		this.arrivalTime = arrivalTime;
	}

	public String getDurationTime() {
		return durationTime;
	}

	public void setDurationTime(String durationTime) {
		this.durationTime = durationTime;
	}

	public double getCostPerSeatEconomic() {
		return costPerSeatEconomic;
	}

	public void setCostPerSeatEconomic(double costPerSeatEconomic) {
		this.costPerSeatEconomic = costPerSeatEconomic;
	}

	public double getCostPerSeatBusiness() {
		return costPerSeatBusiness;
	}

	public void setCostPerSeatBusiness(double costPerSeatBusiness) {
		this.costPerSeatBusiness = costPerSeatBusiness;
	}

}
