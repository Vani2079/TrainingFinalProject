package com.company.Users.dao;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.company.Users.model.User;

@Repository
public interface UserRepository extends CrudRepository<User, Long> {

	User findByEmailAndPassword(String email, String password);

}
