package com.company.Users.service;

import com.company.Users.dto.UserRequestDto;

public interface UserService {

	void saveUserDetails(UserRequestDto userRequestDto);

	void validateUser(String email, String password);

	void checkUserId(Long userId);

}
